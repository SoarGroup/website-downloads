/**
 * 
 */
package edu.umich.dice;

class SoarDiceException extends Exception
{
    private static final long serialVersionUID = 7944707250565125602L;

    public SoarDiceException(String message)
    {
        super(message);
    }
}