package edu.umich.soar.qna;

public class InvalidDataSourceUIDException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1634973694334446602L;

}
