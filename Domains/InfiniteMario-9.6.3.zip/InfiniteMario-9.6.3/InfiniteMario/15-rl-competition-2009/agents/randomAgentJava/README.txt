This java agent is meant to select random actions for all the generalized domains in the rl-competition. This agent does not learn.

The random agent works with all of the domains in the competition.

To recompile just the random java agent:
>> make clean
>> make

in randomAgentJava directory.

>>bash run.bash:
- Starts the randomAgentJava process

You need to start a trainer separately.
