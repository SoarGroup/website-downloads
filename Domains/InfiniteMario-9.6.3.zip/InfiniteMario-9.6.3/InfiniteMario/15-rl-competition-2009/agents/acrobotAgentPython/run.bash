#! /bin/bash
PYTHONPATH=../../system/codecs/Python/src  python src/AcrobotAgent.py
