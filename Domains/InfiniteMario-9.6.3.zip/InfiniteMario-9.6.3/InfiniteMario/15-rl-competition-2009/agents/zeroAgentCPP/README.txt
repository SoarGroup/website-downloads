This c++ agent is meant to select random actions for all the generalized domains in the rl-competition. This agent does not learn.

It just returns 0 for all actions.


To recompile:
>> make clean
>> make

>>bash run.bash:
- Starts the randomAgentCPP process

You need to start a trainer separately.
