#! /bin/bash
PYTHONPATH=../../system/codecs/Python/src/ python src/RandomAgent.py

