This python agent is meant to select random actions for all the generalized domains in the rl-competition. This agent does not learn.

The random agent works with the following domains:
- Helicopter
- Tetris
- Mountain Car
- Sample Polyathlon

To recompile just the random python agent:
>> make clean
>> make

in randomAgentPython directory.

>>run.bash:
- Starts the randomAgentPython process

You need to start a trainer separately.
