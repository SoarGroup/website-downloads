#!/bin/bash


./RL_agent
echo "-- Agent is done"
