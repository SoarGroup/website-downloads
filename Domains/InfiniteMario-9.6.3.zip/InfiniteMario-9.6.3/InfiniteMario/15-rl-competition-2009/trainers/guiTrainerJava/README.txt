This trainer is meant to run graphical experiments with the java domains for the rl-competition.

run.bash:
- Starts RL_glue
- Starts the dynamic environment loader which can load any of the three environments
- Starts a graphical experiment program that can load whichever of the environments

There is no way or need to recompile the gui trainers.

You need to start your own agent.
