#include <iostream>
#include "filter.h"
#include "filter_table.h"
#include "common.h"
#include "scene.h"

using namespace std;

class intersect_filter : public typed_map_filter<bool> {
public:
	intersect_filter(Symbol *root, soar_interface *si, filter_input *input, scene *scn)
	: typed_map_filter<bool>(root, si, input) {}
	
	bool compute(const filter_params *p, bool adding, bool &result, bool &changed) {
		bool new_result;
		const sgnode *a, *b;
		
		if (!get_filter_param(this, p, "a", a) || !get_filter_param(this, p, "b", b))
			return false;
		
		
		new_result = intersects(a, b);
		if (result == new_result) {
			changed = false;
		} else {
			changed = true;
		}
		result = new_result;
		return true;
	}
};

filter *make_intersect_filter(Symbol *root, soar_interface *si, scene *scn, filter_input *input) {
	return new intersect_filter(root, si, input, scn);
}

filter_table_entry *intersect_fill_entry() {
	filter_table_entry *e = new filter_table_entry;
	e->name = "intersect";
	e->parameters.push_back("a");
	e->parameters.push_back("b");
	e->create = &make_intersect_filter;
	return e;
}
