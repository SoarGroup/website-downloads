#!/bin/sh

if [ -z "$1" ]
then
	port=8999
else
	port=$1
fi

case `uname` in
Darwin)
	p=osx
	;;
Linux)
	case `uname -m` in
	i686)
		p=linux32
		;;
	x86_64)
		p=linux64
		;;
	*)
		echo unknown machine >&2
		exit 1
	esac
	;;
*)
	echo unknown OS >&2
	exit 1
esac

PATH=$(dirname $0)/$p:$PATH exec svs_viewer -s $port

