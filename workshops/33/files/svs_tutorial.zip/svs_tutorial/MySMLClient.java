import sml.Agent;
import sml.Kernel;

public class MySMLClient {
	public static class SVSInputCallback implements sml.Agent.RunEventInterface  {
		int x;
		boolean first;
		
		public SVSInputCallback() {
			x = 0;
			first = true;
		}
		
		public void runEventHandler(int id, Object userdata, Agent agent, int phase) {
			String sgel;
			
			if (first) {
				sgel = "a b1 ball world b 1";
				first = false;
			} else {
				sgel = String.format("c b1 p %d 0 0", x);
				x += 1;
			}
			System.out.println("Sending " + sgel);
			agent.SendSVSInput(sgel);
		}
	}
	
	public static void main(String[] args) {
		Kernel kernel = Kernel.CreateKernelInNewThread();
		Agent agent = kernel.CreateAgent("soar");
		System.out.println(agent.ExecuteCommandLine("print s1"));
		
		agent.ExecuteCommandLine("waitsnc -e");
		agent.ExecuteCommandLine("svs connect_viewer 8999");
		
		agent.RegisterForRunEvent(sml.smlRunEventId.smlEVENT_BEFORE_INPUT_PHASE, new SVSInputCallback(), null);		
		if (!agent.SpawnDebugger()) {
			System.err.println("Debugger spawning failed");
			System.exit(1);
		}
		
		while (true) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
		}
	}

}
