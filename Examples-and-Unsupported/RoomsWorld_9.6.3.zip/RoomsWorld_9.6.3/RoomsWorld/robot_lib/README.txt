These are jars that are part of the ROBOT group in the Eclipse projects.
