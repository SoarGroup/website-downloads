This is the Soar Robot Server project.

This depends on Soar Robot Library, as well as other projects.

The command "ant" in this directory will build everything into ../release/[platform] and archive that into ../release/[platform].zip. Within that directory, just opening SoarRobotServer should start the application.
