package april.viewer;

public interface ViewObject
{
    // must implement constructor with signature:
    // public ViewObject(Viewer viewer, String name, Config config);
}
