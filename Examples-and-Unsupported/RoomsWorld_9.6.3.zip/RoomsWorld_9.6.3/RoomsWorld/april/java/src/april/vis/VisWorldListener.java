package april.vis;

/** Interface for listening to changes to VisWorld **/
public interface VisWorldListener
{
    public void worldChanged(VisWorld w);
}
