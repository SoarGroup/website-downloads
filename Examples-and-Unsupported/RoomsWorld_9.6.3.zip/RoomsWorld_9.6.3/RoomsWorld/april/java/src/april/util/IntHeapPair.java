package april.util;

public class IntHeapPair
{
    public int o;
    public double score;
}
