package april.vis;

public interface Colorizer
{
    /** Return AARRGGBB **/
    public int colorize(double p[]);
}
