package april.jmat.menv.node;

import april.jmat.menv.*;

import april.jmat.menv.inst.*;


public interface Node
{
    public int emit(Emit e);
}
