package april.jmat.menv;

public class MEnvRuntimeException extends RuntimeException
{
    public MEnvRuntimeException(String s)
    {
        super(s);
    }
}
