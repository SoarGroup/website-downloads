package april.jmat.ordering;

import april.jmat.*;

public interface Ordering
{
    public int[] getPermutation(Matrix A);
}
