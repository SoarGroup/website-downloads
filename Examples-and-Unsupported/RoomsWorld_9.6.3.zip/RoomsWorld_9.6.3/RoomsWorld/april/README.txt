This is a fork of the April library (2011-05-24, commit f65e3ff2bec98bae226d9dc8db16489cc81b12c8) that we're using just for the Soar Robot project.

To build april.jar:
cd java
ant

Then move april.jar into SoarRobotServer/lib and SoarRobotTablet/assets.
