$Id: README.txt 11042 2009-08-21 19:28:39Z nate.derbinsky $

Eaters 3.0.8 is an example environment for the Soar architecture and is used for 
research and to help teach the basics of Soar in the Soar tutorial.  Eaters 
3.0.8 is installed as a component of the Soar-Suite package.  For more 
information, please see the website:

	http://sitemaker.umich.edu/soar/

____________________
File/Directory list:
--------------------
README.txt       - This file.
INSTALL.txt      - Installation and execution notes.
LICENSE.txt      - The license that Eaters is distributed under.
start-eaters.bat - The Windows file used to start Eaters (see INSTALL file).
init-eaters.tcl  - The Tcl/Tk initialization code for Eaters (see INSTALL file).
agents/          - Example and tutorial Soar agents.
simulator/       - The Eaters Tcl/Tk source code.

--

Updated for the Eaters 3.0.8 release by Jonathan Voigt (voigtjr@gmail.com).
