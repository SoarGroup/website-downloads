#ifndef SOARVERSION_H
#define SOARVERSION_H

// There is also a version string in SoarJavaDebugger doc.Document.java
// Yet another version string in  (root)/SConstruct

#define MAJOR_VERSION_NUMBER 9
#define MINOR_VERSION_NUMBER 2
#define MICRO_VERSION_NUMBER 0
#define GREEK_VERSION_NUMBER 0
#define VERSION_STRING "9.2.0"

#define SML_MAJOR_VERSION_NUMBER 9
#define SML_MINOR_VERSION_NUMBER 2
#define SML_MICRO_VERSION_NUMBER 0
#define SML_GREEK_VERSION_NUMBER 0
#define SML_VERSION_STRING "9.2.0"

#endif // SOARVERSION_H
