#ifndef KERNELSMLDLL_H
#define KERNELSMLDLL_H

// get definition of EXPORT
#include "Export.h"

#endif // KERNELSMLDLL
