package org.msoar.gridmap2d.config;

public interface GameConfig {
	public String title();
}
