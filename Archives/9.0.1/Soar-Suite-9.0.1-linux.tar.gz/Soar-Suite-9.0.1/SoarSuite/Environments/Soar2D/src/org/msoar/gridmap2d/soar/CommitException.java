package org.msoar.gridmap2d.soar;

class CommitException extends Exception {

	CommitException() {
		super();
	}
	
	private static final long serialVersionUID = 1L;

}
