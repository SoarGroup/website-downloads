#ifndef CPPUNIT_TEXTTESTRUNNER_H
#define CPPUNIT_TEXTTESTRUNNER_H

#include <cppunit/ui/text/TextTestRunner.h>

#endif  // CPPUNIT_TEXTTESTRUNNER_H
