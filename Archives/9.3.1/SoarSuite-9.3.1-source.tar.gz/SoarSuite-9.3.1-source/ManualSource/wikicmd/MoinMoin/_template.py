# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - <short description>

    <what this stuff does ... - verbose enough>

    @copyright: 2007 MoinMoin:YourNameHere
    @license: GNU GPL, see COPYING for details.
"""


