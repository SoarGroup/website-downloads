package edu.umich.soar.qna;

public class InvalidQueryUIDException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4154344720484648154L;

}
