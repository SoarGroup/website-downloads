package edu.umich.soar.gridmap2d.config;

public class ClientConfig {
	public String command = null;
	public int timeout = 0;
	public boolean after = true;
}
