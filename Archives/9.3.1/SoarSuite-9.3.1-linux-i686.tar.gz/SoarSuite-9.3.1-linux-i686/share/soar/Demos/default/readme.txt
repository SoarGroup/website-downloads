# default/README
# John Laird

#Updated May 14, 2006
#

#The main default rules are in two files:
# simple.soar holds the basic rules that you probably want to use in
# every Soar system. 
# selection.soar holds the rules to support lookahead search using the
# selection problem space. 

# These rules have also been organized into a Visual Soar project and can
# be found in the selection-vs-project folder

# There is also a file to aid in operator subgoaling: operator-subgoaling.soar





