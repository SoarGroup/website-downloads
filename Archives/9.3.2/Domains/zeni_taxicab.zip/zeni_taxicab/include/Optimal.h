#ifndef OPTIMAL_H
#define OPTIMAL_H

#include <utility>
#include <vector>

namespace Optimal {

  static const size_t start_to_src[4][25] =
    {{0,1,6,7,8, 1,2,5,6,7, 2,3,4,5,6, 3,4,5,6,7, 4,5,6,7,8},
     {8,7,2,1,0, 7,6,3,2,1, 6,5,4,3,2, 7,6,5,4,3, 8,7,6,5,4},
     {7,6,5,4,5, 6,5,4,3,4, 5,4,3,2,3, 6,5,4,1,2, 7,6,5,0,1},
     {4,5,6,7,8, 3,4,5,6,7, 2,3,4,5,6, 1,4,5,6,7, 0,5,6,7,8}};
  static const size_t start_to_dest[4][4] =
    {{0,8,7,4},
     {8,0,5,8},
     {7,5,0,7},
     {4,8,7,0}};
  static const size_t start_to_fuel[25] =
    {5,4,3,4,5, 4,3,2,3,4, 3,2,1,2,3, 4,1,0,3,4, 5,2,1,4,5};
  static const size_t fuel_to_dest[4] =
    {5,5,4,5};
  static const size_t src_to_dest[4][4] =
    {{0,8,7,4},
     {8,0,5,8},
     {7,5,0,7},
     {4,8,7,0}};

  static const size_t start_count = 25;
  static const size_t dest_count = 4;
  static const size_t max_fuel = 12;
  static const size_t min_init_fuel = 5;
  static const size_t end_init_fuel = 13;

  template <typename TYPE>
  float average(const typename std::vector<TYPE> &input) {
    float sum = 0.0f;

    for(typename std::vector<TYPE>::const_iterator it = input.begin(); it != input.end(); ++it)
      sum += float(*it);

    return sum / input.size();
  }

  template <typename TYPE>
  float numerator(const TYPE &count) {
    return 20.0f - float(count);
  }

  template <typename TYPE>
  float reward_many(const std::vector<TYPE> &counts) {
    float sum = 0.0f;
    float div = 0.0f;

    for(typename std::vector<TYPE>::const_iterator it = counts.begin(); it != counts.end(); ++it) {
      sum += float(numerator(*it));
      div += float(*it);
    }

    return sum / div;
  }

  template <typename TYPE>
  float reward_per_step(const TYPE &count) {
    return numerator(count) / float(count);
  }

  struct Result {
    size_t steps;
    float rps;

    Result() : steps(0u) {}
  };

  struct Combined_Results {
    size_t num_trials;
    float average_steps;
    float average_rps_simple;
    float average_rps_paper;
  };

  static Result case_oi_dp[start_count][start_count][dest_count];

  inline Result case_oi(const size_t &start,
                        const size_t &src,
                        const size_t &dest,
                        const size_t & /*fuel*/ = max_fuel)
  {
    Result &r = case_oi_dp[start][src][dest];

    if(r.steps)
      return r;

    r.steps = start_to_src[src][start] + start_to_dest[src][dest] + 2;
    r.rps = reward_per_step(r.steps);

    return r;
  }

  inline Combined_Results case_oi() {
    std::vector<size_t> counts;
    std::vector<float> results;

    const size_t expected_count = start_count * dest_count * dest_count;
    counts.reserve(expected_count);
    results.reserve(expected_count);

    for(size_t start =  0; start != start_count; ++start)
      for(size_t src = 0; src != dest_count; ++src)
        for(size_t dest = 0; dest != dest_count; ++dest)
        {
          const Result r = case_oi(start, src, dest);
          counts.push_back(r.steps);
          results.push_back(r.rps);
        }

    Combined_Results cr;

    cr.num_trials = counts.size();
    cr.average_steps = average(counts);
    cr.average_rps_simple = reward_many(counts);
    cr.average_rps_paper = average(results);

    return cr;
  }

  static Result case_of_dp[start_count][start_count][dest_count][end_init_fuel - min_init_fuel];

  inline Result case_of(const size_t &start,
                        const size_t &src,
                        const size_t &dest,
                        const size_t &fuel)
  {
    Result &r = case_of_dp[start][src][dest][fuel - min_init_fuel];

    if(r.steps)
      return r;

    size_t c = 100;
    const size_t c1 = start_to_src[src][start] + src_to_dest[src][dest];
    if(fuel >= c1)
      c = c1;
    else {
      size_t c2 = 100;
      if(fuel >= start_to_src[src][start] + fuel_to_dest[src])
        c2 = start_to_src[src][start] + fuel_to_dest[src] + 1 + fuel_to_dest[dest];
      const size_t c3 = start_to_fuel[start] + 1 + fuel_to_dest[src] + src_to_dest[src][dest];
      if(c2 < c3)
        c = c2;
      else
        c = c3;
    }
    c += 2;

    r.steps = c;
    r.rps = reward_per_step(r.steps);

    return r;
  }

  inline Combined_Results case_of() {
    std::vector<size_t> counts;
    std::vector<float> results;

    const size_t expected_count = start_count * dest_count * dest_count * (end_init_fuel - min_init_fuel);
    counts.reserve(expected_count);
    results.reserve(expected_count);

    for(size_t start =  0; start != start_count; ++start)
      for(size_t src = 0; src != dest_count; ++src)
        for(size_t dest = 0; dest != dest_count; ++dest)
          for(size_t fuel = min_init_fuel; fuel != end_init_fuel; ++fuel)
          {
            const Result r = case_of(start, src, dest, fuel);
            counts.push_back(r.steps);
            results.push_back(r.rps);
          }

    Combined_Results cr;

    cr.num_trials = counts.size();
    cr.average_steps = average(counts);
    cr.average_rps_simple = reward_many(counts);
    cr.average_rps_paper = average(results);

    return cr;
  }

  static Result case_ui_dp[start_count][start_count][dest_count];

  inline Result case_ui(const size_t &start,
                        const size_t &hidden_src,
                        const size_t &hidden_dest,
                        const size_t & /*fuel*/ = max_fuel)
  {
    Result &r = case_ui_dp[start][hidden_src][hidden_dest];

    if(r.steps)
      return r;

    static const size_t to_nearest[4][2] =
      {{4,3},{5,2},{5,1},{4,0}};
    static const size_t to_nopposite[4][2] =
      {{7,2},{8,0},{7,0},{7,2}};

    std::vector<size_t> counts2;
    std::vector<float> results2;
    size_t count2 = 0;

    for(size_t src = 0; src != dest_count; ++src) {
      std::vector<size_t> counts3;
      std::vector<float> results3;
      size_t count3 = 0;

      size_t count = start_to_src[src][start] + 2;
      for(size_t dest = 0; dest != dest_count; ++dest) {
        const size_t c = count + src_to_dest[src][dest];
        counts3.push_back(c);
        results3.push_back(reward_per_step(c));
        if(hidden_src == src && hidden_dest == dest)
          count3 = c;
      }

      const size_t * transition = to_nearest[src];
      count += transition[0];
      size_t pos = transition[1];
      for(size_t dest = 0; dest != dest_count; ++dest) {
        const size_t c = count + src_to_dest[pos][dest];
        counts3.push_back(c);
        results3.push_back(reward_per_step(c));
        if(hidden_src == pos && hidden_dest == dest)
          count3 = c;
      }

      transition = to_nopposite[pos];
      count += transition[0];
      pos = transition[1];
      for(size_t dest = 0; dest != dest_count; ++dest) {
        const size_t c = count + src_to_dest[pos][dest];
        counts3.push_back(c);
        results3.push_back(reward_per_step(c));
        if(hidden_src == pos && hidden_dest == dest)
          count3 = c;
      }

      transition = to_nearest[pos];
      count += transition[0];
      pos = transition[1];
      for(size_t dest = 0; dest != dest_count; ++dest) {
        const size_t c = count + src_to_dest[pos][dest];
        counts3.push_back(c);
        results3.push_back(reward_per_step(c));
        if(hidden_src == pos && hidden_dest == dest)
          count3 = c;
      }

      if(counts2.empty() || reward_many(counts3) > reward_many(counts2)) {
        counts2 = counts3;
        results2 = results3;
        count2 = count3;
      }
    }

    r.steps = count2;
    r.rps = reward_per_step(r.steps);

    return r;
  }

  inline Combined_Results case_ui() {
    std::vector<size_t> counts;
    std::vector<float> results;

    const size_t expected_count = start_count * dest_count * dest_count;
    counts.reserve(expected_count);
    results.reserve(expected_count);

    for(size_t start =  0; start != start_count; ++start)
      for(size_t src = 0; src != dest_count; ++src)
        for(size_t dest = 0; dest != dest_count; ++dest)
        {
          const Result r = case_ui(start, src, dest);
          counts.push_back(r.steps);
          results.push_back(r.rps);
        }

    Combined_Results cr;

    cr.num_trials = counts.size();
    cr.average_steps = average(counts);
    cr.average_rps_simple = reward_many(counts);
    cr.average_rps_paper = average(results);

    return cr;
  }

  static Result case_uf_dp[start_count][start_count][dest_count][end_init_fuel - min_init_fuel];

  inline Result case_uf(const size_t &start,
                        const size_t &hidden_src,
                        const size_t &hidden_dest,
                        const size_t &fuel)
  {
    Result &r = case_uf_dp[start][hidden_src][hidden_dest][fuel - min_init_fuel];

    if(r.steps)
      return r;

    static const size_t to_nearest[4][2] =
      {{4,3},{5,2},{5,1},{4,0}};
    static const size_t to_nopposite[4][2] =
      {{10,2},{11,0},{10,0},{10,2}};

    std::vector<size_t> counts2;
    std::vector<float> results2;
    size_t count2 = 0;

    for(size_t src = 0; src != dest_count; ++src) {
      std::vector<size_t> counts3;
      std::vector<float> results3;
      size_t count3 = 0;

      size_t count = 0;
      size_t fuel_remaining = fuel;
      if(fuel >= start_to_src[src][start] &&
         fuel - start_to_src[src][start] >= max_fuel - fuel_to_dest[src])
        count += start_to_src[src][start];
      else {
        count += start_to_fuel[start] + 1 + fuel_to_dest[src];
        fuel_remaining = max_fuel - fuel_to_dest[src];
      }
      for(size_t dest = 0; dest != dest_count; ++dest) {
        const size_t c = count + src_to_dest[src][dest] + 2;
        counts3.push_back(c);
        results3.push_back(reward_per_step(c));
        if(hidden_src == src && hidden_dest == dest)
          count3 = c;
      }

      const size_t * transition = to_nearest[src];
      count += transition[0];
      fuel_remaining -= transition[0];
      size_t pos = transition[1];
      for(size_t dest = 0; dest != dest_count; ++dest) {
        size_t c = count + 2;
        if(fuel_remaining >= src_to_dest[pos][dest])
          c += src_to_dest[pos][dest];
        else
          c += fuel_to_dest[pos] + 1 + fuel_to_dest[dest];
        counts3.push_back(c);
        results3.push_back(reward_per_step(c));
        if(hidden_src == pos && hidden_dest == dest)
          count3 = c;
      }

      transition = to_nopposite[pos];
      count += transition[0];
      fuel_remaining = max_fuel - fuel_to_dest[transition[1]];
      pos = transition[1];
      for(size_t dest = 0; dest != dest_count; ++dest) {
        const size_t c = count + src_to_dest[pos][dest] + 2;
        counts3.push_back(c);
        results3.push_back(reward_per_step(c));
        if(hidden_src == pos && hidden_dest == dest)
          count3 = c;
      }

      transition = to_nearest[pos];
      count += transition[0];
      fuel_remaining -= transition[0];
      pos = transition[1];
      for(size_t dest = 0; dest != dest_count; ++dest) {
        size_t c = count + 2;
        if(fuel_remaining >= src_to_dest[pos][dest])
          c += src_to_dest[pos][dest];
        else
          c += fuel_to_dest[pos] + 1 + fuel_to_dest[dest];
        counts3.push_back(c);
        results3.push_back(reward_per_step(c));
        if(hidden_src == pos && hidden_dest == dest)
          count3 = c;
      }

      if(counts2.empty() || reward_many(counts3) > reward_many(counts2)) {
        counts2 = counts3;
        results2 = results3;
        count2 = count3;
      }
    }

    r.steps = count2;
    r.rps = reward_per_step(r.steps);

    return r;
  }

  inline Combined_Results case_uf() {
    std::vector<size_t> counts;
    std::vector<float> results;

    const size_t expected_count = start_count * dest_count * dest_count * (end_init_fuel - min_init_fuel);
    counts.reserve(expected_count);
    results.reserve(expected_count);

    for(size_t fuel = min_init_fuel; fuel != end_init_fuel; ++fuel)
      for(size_t start =  0; start != start_count; ++start)
        for(size_t src = 0; src != dest_count; ++src)
          for(size_t dest = 0; dest != dest_count; ++dest)
            {
              const Result r = case_uf(start, src, dest, fuel);
              counts.push_back(r.steps);
              results.push_back(r.rps);
            }

    Combined_Results cr;

    cr.num_trials = counts.size();
    cr.average_steps = average(counts);
    cr.average_rps_simple = reward_many(counts);
    cr.average_rps_paper = average(results);

    return cr;
  }

}

#endif
