#ifndef INPUT_LINK_H
#define INPUT_LINK_H

#include <Soar_Agent.h>

class Input_Link {
  Input_Link(const Input_Link &);
  Input_Link operator=(const Input_Link &);

public:
  class WME_Node {
    WME_Node(const WME_Node &);
    WME_Node operator=(const WME_Node &);

    enum Type {NONE, ID, STRING, INT, FLOAT};

  public:
    WME_Node(Soar_Agent &agent, sml::Identifier &parent, const Zeni::String &index);
    ~WME_Node();

    WME_Node & operator[](const Zeni::String &index);

    void operator=(const Zeni::String &s);
    void operator=(const int &i);
    void operator=(const float &f);

    void operator=(const bool &s) {
      *this = s ? Zeni::String("true") : Zeni::String("false");
    }

    void operator=(const size_t &i) {
      *this = int(i);
    }

    void erase(const Zeni::String &s);

  private:
    Soar_Agent &m_agent;
    sml::Identifier &m_parent;
    Zeni::String m_index;

    Type m_type;
    union {
      sml::Identifier * ident;
      sml::StringElement * s;
      sml::IntElement * i;
      sml::FloatElement * f;
    } m_ptr;

    void * m_value;

    void destroy_pv();

    std::map<Zeni::String, WME_Node *> m_nodes;
  };

  Input_Link(Soar_Agent &agent);
  ~Input_Link();

  WME_Node & operator[](const Zeni::String &index);

  void erase(const Zeni::String &s);

  void clear();

private:
  Soar_Agent &m_agent;
  std::map<Zeni::String, WME_Node *> m_nodes;
};

#endif
