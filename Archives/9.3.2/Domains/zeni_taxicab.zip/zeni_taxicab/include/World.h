#ifndef WORLD_H
#define WORLD_H

#include <zenilib.h>
#include <utility>

typedef std::pair<size_t, size_t> Point;

class World {
  typedef std::vector<bool> Walls1D;
  typedef std::vector<Walls1D> Walls2D;

public:
  enum Type {RED = 0, GREEN = 1, BLUE = 2, YELLOW = 3, TAXI = 4, FUEL = 5, NORMAL = 6, NONE = 7};

  World(const Zeni::String &filename, const bool &omniscient, const bool &infinite, const int &seed);

  void reinit();

  float move_north();
  float move_south();
  float move_east();
  float move_west();
  float pickup();
  float putdown();
  float fillup();

  size_t width()  const {return m_size.first;}
  size_t height() const {return m_size.second;}
  const Point & fuel()   const {return m_fuel;}
  const Point & red()    const {return m_red;}
  const Point & green()  const {return m_green;}
  const Point & blue()   const {return m_blue;}
  const Point & yellow() const {return m_yellow;}
  const Point & taxi()   const {return m_taxi;}
  const size_t & energy() const {return m_energy;}
  Type source()      const;
  Type destination() const;
  const Type & passenger()   const {return m_passenger;}
  bool north_wall(const Point &position) const;
  bool east_wall(const Point &position) const;
  bool terminal() const {return m_success || m_failure;}
  bool success() const {return m_success;}
  bool failure() const {return m_failure;}
  bool omniscient() const {return m_omniscient;}
  bool infinite() const {return m_infinite;}

  const Point & original_start() const {return m_start;}
  Type original_source()      const {return m_source;}
  Type original_destination() const {return m_destination;}
  size_t original_energy() const {return m_original_energy;}

  static Zeni::String type_to_string(const Type &type);
  const Point & type_to_pos(const Type &type) const;
  Type pos_to_type(const Point &point) const;

  Zeni::Random & random() {
    return m_random;
  }

private:
  float perform_move(const Point &dest);

  Zeni::Random m_random;

  Point m_size;

  Point m_fuel;
  Point m_red;
  Point m_green;
  Point m_blue;
  Point m_yellow;

  Point m_taxi;
  Point m_start; ///< Needed for original_* functions only
  std::pair<size_t, size_t> m_initial_energy;
  size_t m_full_energy;
  size_t m_energy;
  size_t m_original_energy; ///< Needed for original_* functions only
  Type m_source;
  Type m_destination;
  Type m_passenger;

  Walls2D m_north_walls;
  Walls2D m_east_walls;

  bool m_success;
  bool m_failure;
  bool m_omniscient;
  bool m_infinite;
};

#endif
