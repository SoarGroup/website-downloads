#!/bin/bash

cp config/zenilib.orig Taxicab.app/Contents/zenilib/config/
pushd Taxicab.app/Contents/MacOS

rm ~/.Zeni_Taxicab/config/zenilib.xml &> /dev/null
cp ../zenilib/config/zenilib.orig ../zenilib/config/zenilib.xml

SEED=$RANDOM
echo seed=$SEED

./application --informed --finite --seed $SEED --learn 50 0.99997 0.5 agents/taxi-hrl-oracle.soar 52000

popd

cp Taxicab.app/Contents/zenilib/stderr.txt ./
cp Taxicab.app/Contents/zenilib/stdout.txt ./
