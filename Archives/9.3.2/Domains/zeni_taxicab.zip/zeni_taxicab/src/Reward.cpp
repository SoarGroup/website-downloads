#include <zenilib.h>

#include "Reward.h"

Reward::Reward()
: m_total(0.0f), m_current(0.0f), m_steps(0)
{
}

float Reward::reward_per_step() const {
  return m_steps ? (m_total / m_steps) : 0.0f;
}

void Reward::reward(const float &value, const bool &step) {
  m_total += value;
  m_current = value;

  if(step)
    ++m_steps;
}

Future_Reward::Future_Reward()
: reward_per_step(0.0f),
one_shot_reward(0.0f)
{
}

bool Future_Reward::operator<(const Future_Reward &rhs) const {
  return reward_per_step < rhs.reward_per_step ||
    (reward_per_step == rhs.reward_per_step &&
    one_shot_reward < rhs.one_shot_reward);
}
