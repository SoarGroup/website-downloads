#include <zenilib.h>

#include "World.h"

//#define GUIDE_LEARNING

using namespace Zeni;

World::World(const Zeni::String &filename, const bool &omniscient, const bool &infinite, const int &seed)
: m_random(seed),
m_omniscient(omniscient),
m_infinite(infinite)
{
  XML_Document file(filename);
  XML_Element world = file["world"];

  {XML_Element size = world["size"];
    m_size.first  = size["x"].to_int();
    m_size.second = size["y"].to_int();
  }
  {XML_Element fuel = world["fuel"];
    m_fuel.first  = fuel["x"].to_int();
    m_fuel.second = fuel["y"].to_int();
  }
  {XML_Element red = world["red"];
    m_red.first  = red["x"].to_int();
    m_red.second = red["y"].to_int();
  }
  {XML_Element green = world["green"];
    m_green.first  = green["x"].to_int();
    m_green.second = green["y"].to_int();
  }
  {XML_Element blue = world["blue"];
    m_blue.first  = blue["x"].to_int();
    m_blue.second = blue["y"].to_int();
  }
  {XML_Element yellow = world["yellow"];
    m_yellow.first  = yellow["x"].to_int();
    m_yellow.second = yellow["y"].to_int();
  }
  {XML_Element energy = world["energy"];
    m_initial_energy.first  = energy["min"].to_int();
    m_initial_energy.second = energy["max"].to_int();
    m_full_energy           = energy["full"].to_int();
  }

  m_north_walls.resize(m_size.first, Walls1D(m_size.second - 1u, false));
  m_east_walls.resize(m_size.first - 1u, Walls1D(m_size.second, false));

  {XML_Element walls = world["walls"];
    {XML_Element north = walls["north"];
      for(XML_Element wall = north.first(); wall.good(); wall = wall.next())
        m_north_walls.at(wall["x"].to_int()).at(wall["y"].to_int()) = true;
    }
    {XML_Element east = walls["east"];
      for(XML_Element wall = east.first(); wall.good(); wall = wall.next())
        m_east_walls.at(wall["x"].to_int()).at(wall["y"].to_int()) = true;
    }
  }

  reinit();

  if(Window::is_enabled())
    Zeni::get_Window().set_title("Taxicab Domain (" +
      Zeni::String(m_infinite ? "Infinite" : "Finite") +
      " " +
      Zeni::String(m_omniscient ? "Informed" : "Uninformed") + 
      ")");
}

#ifdef GUIDE_LEARNING

struct Start_Condition {
  Point start;
  size_t energy;
  World::Type source;
  World::Type destination;
};

static std::list<Start_Condition> g_start_conditions;

#endif

void World::reinit()
{
#ifdef GUIDE_LEARNING
  if(g_start_conditions.empty()) {
    std::vector<Start_Condition> scs;

    for(size_t x = 0u, xend = m_size.first; x != xend; ++x)
      for(size_t y = 0u, yend = m_size.second; y != yend; ++y)
        for(size_t e = m_infinite ? m_full_energy : m_initial_energy.first, eend = m_infinite ? m_full_energy + 1 : m_initial_energy.second + 1; e != eend; ++e)
          for(size_t s = 0u, send = TAXI; s != send; ++s)
            for(size_t d = 0u, dend = TAXI; d != dend; ++d) {
              Start_Condition sc = {Point(x,y), e, World::Type(s), World::Type(d)};
              scs.push_back(sc);
            }

    std::random_shuffle(scs.begin(), scs.end());

    for(std::vector<Start_Condition>::const_iterator it = scs.begin(), iend = scs.end(); it != iend; ++it)
      g_start_conditions.push_back(*it);
  }

  const Start_Condition &sc = g_start_conditions.front();

  m_taxi = sc.start;
  m_energy = sc.energy;
  m_source = sc.source;
  m_destination = sc.destination;

  g_start_conditions.pop_front();
#else
  m_taxi = Point(m_random.rand_lt(int(m_size.first)), m_random.rand_lt(int(m_size.second)));
  m_energy = m_infinite
           ? m_full_energy
           : (m_random.rand_lt(int(m_initial_energy.second - m_initial_energy.first + 1u)) + m_initial_energy.first);
  m_source = World::Type(m_random.rand_lt(TAXI));
  m_destination = World::Type(m_random.rand_lt(TAXI));
#endif

  m_start = m_taxi;
  m_original_energy = m_energy;
  m_passenger = m_source;

  m_success = false;
  m_failure = false;
}

float World::move_north() {
  const Point next(m_taxi.first, m_taxi.second + 1u);
  if(next.second != m_size.second && !m_north_walls[m_taxi.first][m_taxi.second])
    return perform_move(next);
  return -1.0f;
}

float World::move_south() {
  const Point next(m_taxi.first, m_taxi.second - 1u);
  if(m_taxi.second && !m_north_walls[next.first][next.second])
    return perform_move(next);
  return -1.0f;
}

float World::move_east() {
  const Point next(m_taxi.first + 1u, m_taxi.second);
  if(next.first != m_size.first && !m_east_walls[m_taxi.first][m_taxi.second])
    return perform_move(next);
  return -1.0f;
}

float World::move_west() {
  const Point next(m_taxi.first - 1u, m_taxi.second);
  if(m_taxi.first && !m_east_walls[next.first][next.second])
    return perform_move(next);
  return -1.0f;
}

float World::pickup() {
  if(m_passenger != TAXI &&
     type_to_pos(m_passenger) == m_taxi)
  {
    m_passenger = TAXI;
    return -1.0f;
  }
  else
    return -10.0f;
}

float World::putdown() {
  const Type type = pos_to_type(m_taxi);

  if(m_passenger == TAXI &&
     type == m_destination)
  {
    m_passenger = type;
    m_success = true;
    return 20.0f;
  }
  else
    return -10.0f;
}

float World::fillup() {
  if(m_taxi == m_fuel)
  {
    m_energy = 12u;
    return -1.0f;
  }
  else
    return -10.0f;
}

World::Type World::source() const {
  if(m_omniscient || m_passenger == TAXI)
    return m_source;
  else
    return TAXI;
}

World::Type World::destination() const {
  if(m_omniscient || m_passenger == TAXI)
    return m_destination;
  else
    return TAXI;
}

bool World::north_wall(const Point &position) const {
  if(position.first < m_size.first &&
     position.second < m_size.second && // necessary in case of negative overflow
     position.second + 1u < m_size.second)
    return m_north_walls[position.first][position.second];
  else
    return true;
}

bool World::east_wall(const Point &position) const {
  if(position.first < m_size.first && // necessary in case of negative overflow
     position.first + 1u < m_size.first &&
     position.second < m_size.second)
    return m_east_walls[position.first][position.second];
  else
    return true;
}

Zeni::String World::type_to_string(const Type &type) {
  switch(type) {
    case RED:    return "red";    break;
    case GREEN:  return "green";  break;
    case BLUE:   return "blue";   break;
    case YELLOW: return "yellow"; break;
    case FUEL:   return "fuel";   break;
    case NORMAL: return "normal"; break;
    case NONE:   return "none";   break;
    case TAXI:
    default:     return "taxi";   break;
  }
}

const Point & World::type_to_pos(const Type &type) const {
  switch(type) {
    case RED:    return m_red;    break;
    case GREEN:  return m_green;  break;
    case BLUE:   return m_blue;   break;
    case YELLOW: return m_yellow; break;
    case FUEL:   return m_fuel;   break;
    case TAXI:
    default:     return m_taxi;   break;
  }
}

World::Type World::pos_to_type(const Point &point) const {
  if(point.first < m_size.first && point.second < m_size.second) {
    if(point == m_red)
      return RED;
    else if(point == m_green)
      return GREEN;
    else if(point == m_blue)
      return BLUE;
    else if(point == m_yellow)
      return YELLOW;
    else if(point == m_fuel)
      return FUEL;
    else
      return NORMAL;
  }
  else
    return NONE;
}

float World::perform_move(const Point &dest) {
  if(m_energy) {
    if(!m_infinite)
      --m_energy;
    m_taxi = dest;
    return -1.0f;
  }
  else {
    m_failure = true;
    return -20.0f;
  }
}
