package edu.umich.dice3.gamestate.exceptions;

public class DiceActionException extends Exception {

	private static final long serialVersionUID = -4433357575320116500L;

	public DiceActionException(String message)
	{
		super(message);
	}
}


