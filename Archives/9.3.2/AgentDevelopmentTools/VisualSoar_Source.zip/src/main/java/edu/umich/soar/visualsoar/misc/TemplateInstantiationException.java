package edu.umich.soar.visualsoar.misc;

public class TemplateInstantiationException extends Exception {
	public TemplateInstantiationException(String s) {
		super(s);
	}
}
