//const char* kTimestamp = __TIME__;
//const char* kDatestamp = __DATE__;
//* Last build of Soar 9.6.0 occurred at Mon Jan 16 17:52:12 2017 *//
