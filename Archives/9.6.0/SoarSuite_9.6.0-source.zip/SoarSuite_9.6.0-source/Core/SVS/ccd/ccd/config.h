#ifndef __CCD_CONFIG_H__
#define __CCD_CONFIG_H__


#define CCD_DOUBLE

#endif /* __CCD_CONFIG_H__ */
