package edu.umich.dice3;

public class DiceRuleMetadata
{
    public String ruleText;
    public boolean isRl;
    
    public DiceRuleMetadata(String ruleText)
    {
        this.ruleText = ruleText;
    }
    
    @Override
    public String toString()
    {
        // TODO implement
        return "TODO implement";
    }
}
