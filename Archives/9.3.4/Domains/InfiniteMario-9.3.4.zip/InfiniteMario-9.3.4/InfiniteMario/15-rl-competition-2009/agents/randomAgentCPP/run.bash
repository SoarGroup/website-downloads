#!/bin/bash


bin/RL_agent
echo "-- Agent is done"
