#!/usr/bin/env bash
export LD_LIBRARY_PATH=`pwd`
java -jar SoarRobotServer.jar
