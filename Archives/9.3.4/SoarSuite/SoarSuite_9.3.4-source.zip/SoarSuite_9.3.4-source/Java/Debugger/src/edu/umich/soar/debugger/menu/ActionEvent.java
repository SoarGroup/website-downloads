/********************************************************************************************
 *
 * ActionEvent.java
 * 
 * Description:	
 * 
 * Created on 	Feb 15, 2005
 * @author 		Douglas Pearson
 * 
 * Developed by ThreePenny Software <a href="http://www.threepenny.net">www.threepenny.net</a>
 ********************************************************************************************/
package edu.umich.soar.debugger.menu;

/************************************************************************
 * 
 * Just included for compatability with Swing. Currently has no content.
 * 
 ************************************************************************/
public class ActionEvent
{

}
