package edu.umich.soar.visualsoar.parser;

public final class NaturallyUnaryPreference extends PreferenceSpecifier {
	public NaturallyUnaryPreference(int type) {
		super(type);
	}
}
