Soar Suite version 8.6.4 BETA

Extract to a location of your choosing and run the batch files.

Java version 1.5 or better must be installed on your system and
in the path. You can check what version of Java is in your path
by running the command: 

Start menu -> Run -> cmd
Then type in the command line window: java -version

If you have an old version of Java, you may need to uninstall it
to get the new version to work.