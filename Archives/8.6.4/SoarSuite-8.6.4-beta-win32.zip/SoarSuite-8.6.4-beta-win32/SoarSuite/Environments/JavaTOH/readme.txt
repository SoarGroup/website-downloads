The complete working code is in the src directory.
It can be built using build.bat (on Windows) or build.sh (other platforms).

The tutorial directory contains a version of the source code without any of the SML stuff in it, along with a document that shows how to add it all in.
It can be built using tutorial/build.bat.