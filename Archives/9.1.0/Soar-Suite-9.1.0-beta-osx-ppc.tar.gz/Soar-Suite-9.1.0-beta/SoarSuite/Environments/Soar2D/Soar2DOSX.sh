#!/bin/sh
java -ea -XstartOnFirstThread -jar Soar2D.jar
