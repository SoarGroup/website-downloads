Soar Suite version 9.1.0-beta

Soar is no longer installed to Program Files. Simply extract and run.

To run the common Soar applications, double click the files in this folder.
The Soar tutorial is located inside the Documentation folder.

See announce.txt for more information.
