package soar2d.player;

import org.eclipse.swt.graphics.Image;

public class RadarCell {
	public boolean missiles;
	public static Image missilesImage;
	
	public boolean health;
	public static Image healthImage;
	
	public boolean energy;
	public static Image energyImage;
	
	public boolean obstacle;
	public static Image obstacleImage;
	
	public static Image openImage;
	
	public Player player;
}
