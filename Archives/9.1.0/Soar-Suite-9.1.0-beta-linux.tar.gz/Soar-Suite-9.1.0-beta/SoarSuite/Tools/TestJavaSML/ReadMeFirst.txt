TestJavaSML
===========

This is a simple project to demonstrate and test the use of Soar through Java.

You can build this example by running buildJava.bat. The resulting TestJavaSML.jar file will be copied to the SoarLibrary/bin location (i.e. where the supporting libraries are located) and can be run from there.