package soar2d.visuals;

import org.eclipse.swt.*;
import org.eclipse.swt.widgets.*;

import soar2d.map.GridMap;
import soar2d.player.Player;

public class AgentDisplay extends Composite {
	
	public AgentDisplay(final Composite parent) {
		super(parent, SWT.NONE);
	}

	void selectPlayer(Player player) {
		assert false;
	}

	void worldChangeEvent() {
		assert false;
	}

	void updateButtons() {
		assert false;
	}

	void agentEvent() {
		assert false;
	}

	public void setMap(GridMap map) {
	}
}
