#!/bin/sh
cd SoarSuite/SoarLibrary/bin
export DYLD_LIBRARY_PATH="../lib"
export LD_LIBRARY_PATH="../lib"

java -jar VisualSoar.jar
