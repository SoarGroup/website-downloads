#!/bin/sh

cd ../../SoarLibrary/bin
wish ../../Environments/TclEaters/Eaters/init-eaters.tcl
