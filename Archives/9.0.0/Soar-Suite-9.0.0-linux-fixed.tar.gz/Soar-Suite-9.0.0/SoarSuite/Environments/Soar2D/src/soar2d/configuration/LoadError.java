package soar2d.configuration;

public class LoadError extends Exception {
	static final long serialVersionUID = 0;
	
	public LoadError(String message) {
		super(message);
	}
}

