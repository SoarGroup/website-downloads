
extern void askCallback( soar_callback_agent the_agent,
			 soar_callback_data data,
			 soar_call_data call_data );
