extern int number_received;
extern int last_tt;


extern void io_input_fn( agent *a, soar_callback_data data,
						 soar_call_data call_data );


extern void io_output_fn( agent *a, soar_callback_data data,
						  soar_call_data call_data );

