/*************************************************************************
 *
 *  file:  agent.c
 *
 * =======================================================================
 *  Initialization for the agent structure.  Also the cleanup routine
 *  when an agent is destroyed.  These routines are usually replaced
 *  by the same-named routines in the Tcl interface file soarAgent.c
 *  The versions in this file are used only when not linking in Tcl.
 *  HOWEVER, this code should be maintained, and the agent structure
 *  must be kept up to date.
 * =======================================================================
 *
 * Copyright (c) 1995-1999 Carnegie Mellon University,
 *                         The Regents of the University of Michigan,
 *                         University of Southern California/Information
 *                         Sciences Institute.  All rights reserved.
 *
 * The Soar consortium proclaims this software is in the public domain, and
 * is made available AS IS.  Carnegie Mellon University, The University of 
 * Michigan, and The University of Southern California/Information Sciences 
 * Institute make no warranties about the software or its performance,
 * implied or otherwise.
 * =======================================================================
 */
/* ===================================================================
                     Agent-related functions
   =================================================================== */

#include "soarkernel.h"
#include "scheduler.h"
#include "sysdep.h"


agent *soar_agent;

list *all_soar_agents = NIL;

int agent_counter = -1;
int agent_count = -1;

char * soar_version_string;

extern int soar_agent_ids[];




/*
  Try to assign a unique and previously unassigned id.  If none are
   available, assign a unique, but previously assigned id.
*/
int next_available_agent_id() {
  int i;
  
  for( i = 0; i < MAX_SIMULTANEOUS_AGENTS; i++ ) {
    if ( soar_agent_ids[i] == UNTOUCHED ) {
      soar_agent_ids[i] = ALLOCATED;
      return i;
    }
  }
  for( i = 0; i < MAX_SIMULTANEOUS_AGENTS; i++ ) {
    if ( soar_agent_ids[i] == TOUCHED ) {
      soar_agent_ids[i] = ALLOCATED;
      return i;
    }
  }
  {
    char msg[128];
    sprintf( msg, "agent.c: Error: Too many simultaneous agents (> %d\n", MAX_SIMULTANEOUS_AGENTS );

  abort_with_fatal_error( msg );
  }
  return -1;   /* To placate compilier */
}



#ifdef ATTENTION_LAPSE
/* RMJ;
   When doing attentional lapsing, we need a function that determines
   when (and for how long) attentional lapses should occur.  This
   will normally be provided as a user-defined TCL procedure.
*/

long init_lapse_duration( TIMER_VALUE *tv ) {
   int ret;
   long time_since_last_lapse;
   char buf[128];

   start_timer (current_real_time);
   timersub(current_real_time, tv, current_real_time);
   time_since_last_lapse = (long)(1000 * timer_value( tv ) );

   if ( soar_exists_callback( soar_agent, INIT_LAPSE_DURATION_CALLBACK ) ) {

     /* SW 11.07.00
      *
      *  Modified this to use the generic soar interface, as opposed
      *  to being Tcl specific.  This requires a new callback
      *  in particular, here the callback receives the value 
      *  time_since_last_lapse, and must RESET this value to
      *  the appropriate number
      */
     soar_invoke_callback( soar_agent, INIT_LAPSE_DURATION_CALLBACK,
			   (void *)&time_since_last_lapse );
     
     return time_since_last_lapse;
   }
   return 0;
}


#endif




/* ===================================================================
   
                           Initialization Function

=================================================================== */



void init_soar_agent(void) {

  /* --- initialize everything --- */
  init_memory_utilities();
  init_symbol_tables();
  create_predefined_symbols();
  init_production_utilities();
  init_built_in_rhs_functions ();
  init_rete ();
  init_lexer ();
  init_firer ();
  init_decider ();
  init_soar_io ();
  init_chunker ();
  init_sysparams ();
  init_tracing ();
  init_explain();  /* AGR 564 */
#ifdef REAL_TIME_BEHAVIOR
  /* RMJ */
  init_real_time();
#endif
#ifdef ATTENTION_LAPSE
  /* RMJ */
  init_attention_lapse();
#endif


  /* --- add default object trace formats --- */
  add_trace_format (FALSE, FOR_ANYTHING_TF, NIL,
                    "%id %ifdef[(%v[name])]");
  add_trace_format (FALSE, FOR_STATES_TF, NIL,
                    "%id %ifdef[(%v[attribute] %v[impasse])]");
  { Symbol *evaluate_object_sym;
    evaluate_object_sym = make_sym_constant ("evaluate-object");
    add_trace_format (FALSE, FOR_OPERATORS_TF, evaluate_object_sym,
                      "%id (evaluate-object %o[object])");
    symbol_remove_ref (evaluate_object_sym);
  }
  /* --- add default stack trace formats --- */
  add_trace_format (TRUE, FOR_ANYTHING_TF, NIL,
                    "%right[6,%dc]: %rsd[   ]==>S: %id %ifdef[(%v[name])]");
  add_trace_format (TRUE, FOR_STATES_TF, NIL,
                    "%right[6,%dc]: %rsd[   ]==>S: %cs");
  add_trace_format (TRUE, FOR_OPERATORS_TF, NIL,
                    "%right[6,%dc]: %rsd[   ]   O: %co");
  reset_statistics ();
}




