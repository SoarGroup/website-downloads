void remove_built_in_rhs_functions (void);
void remove_rhs_function(Symbol *name);