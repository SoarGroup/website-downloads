

void cb_soarResult_AppendResult( agent * a, soar_callback_data d, 
				 soar_call_data c );

