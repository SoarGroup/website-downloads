/*************************************************************************
 *
 *  file:  explain.h
 *
 * =======================================================================
 *
 * Copyright (c) 1995-1999 Carnegie Mellon University,
 *                         The Regents of the University of Michigan,
 *                         University of Southern California/Information
 *                         Sciences Institute.  All rights reserved.
 *
 * The Soar consortium proclaims this software is in the public domain, and
 * is made available AS IS.  Carnegie Mellon University, The University of 
 * Michigan, and The University of Southern California/Information Sciences 
 * Institute make no warranties about the software or its performance,
 * implied or otherwise.
 * =======================================================================
 */

/* we really only needs these for interface.c, so maybe just
 * explicitly include them there and get rid of this file... kjc */

/* About 80 lines of stuff deleted.  AGR 564  2-May-94 */

/* KBS commented this out -- redundant with agent variable */
/* extern bool explain_flag;   Flag for whether we're explaining or not */

extern bool explain_interface_routine (void);
extern char *help_on_explain[];

