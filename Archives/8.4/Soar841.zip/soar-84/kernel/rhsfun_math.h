/*************************************************************************
 *
 *  file:  rhsfun_math.h
 *
 * =======================================================================
 *  used only by rhsfun.c ...  explicitly add to file and drop this one?
 *  
 * =======================================================================
 *
 * Copyright (c) 1995-1999 Carnegie Mellon University,
 *                         The Regents of the University of Michigan,
 *                         University of Southern California/Information
 *                         Sciences Institute.  All rights reserved.
 *
 * The Soar consortium proclaims this software is in the public domain, and
 * is made available AS IS.  Carnegie Mellon University, The University of 
 * Michigan, and The University of Southern California/Information Sciences 
 * Institute make no warranties about the software or its performance,
 * implied or otherwise.
 * =======================================================================
 */



extern void init_built_in_rhs_math_functions (void);
extern void remove_built_in_rhs_math_functions (void);
