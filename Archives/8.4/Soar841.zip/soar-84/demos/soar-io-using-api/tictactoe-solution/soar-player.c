#include "soar-player.h"
#include "soar_ecore_api.h"


SoarPlayer *gTheSoarPlayer;



io_wme *get_output_wme( char *attribute, io_wme *head );
void tttPrint( agent *a, soar_callback_data data, soar_call_data cd );
void tttOutput( agent *a, soar_callback_data data, soar_call_data cd );
void tttInput( agent *a, soar_callback_data data, soar_call_data cd );

/**
	Create the Soar Agent to Play tic-tac-toe.
	Soar is completely un-initialized when this
	function is called.  We do all the initialization
	here and then set up the global pointer
	(gTheSoarPlayer) to keep track of the environment
	side agent info
*/
  
void createSoarPlayer( Marker myMarker ) {

	SoarPlayer *p;
	psoar_agent psa;


	p = malloc( sizeof( SoarPlayer ) );

	soar_cInitializeSoar();		/* This must only be done once! */
	
	gTheSoarPlayer = p;			/* Set up global pointer */

	p->myMarker = myMarker;

    soar_cCreateAgent( "ai" );

	/** 
	 *   The first agent created, will also be the current agent, 
	 *   but here we set it anyway, just for illustration
	 */
	psa = soar_cGetAgentByName( "ai" );
	soar_cSetCurrentAgent( psa );

	/* The all important callbacks */
	soar_cPushCallback( psa, PRINT_CALLBACK, (soar_callback_fn) tttPrint, NULL, NULL );
	soar_cAddInputFunction( psa, (soar_callback_fn) tttInput, NULL, NULL, "input-link" );
	soar_cAddOutputFunction( psa, (soar_callback_fn) tttOutput, NULL, NULL, "output-link" );

	/* Load agent code */
	sourceProductionsFromFile( "tictactoe.soar" );
}

/**
 * set up the agent's working memory.
 * This is called only on the agent's
 * FIRST input-cycle
 */
void initialize_agent_memory() {

	int i;
	psoar_wme w;
	char tempStr[20];
	char inputLinkId[20];

	/*  Find the input link id (usually 'I2') */
	soar_cGetAgentInputLinkId( soar_cGetCurrentAgent(), inputLinkId );
	
	for( i = 0; i < 9; i++ ) {

		/* 
		 * Add the 'square' augmentations, and store away
		 * the identifier used to add/remove children
		 */
		soar_cAddWme( inputLinkId, "^square", "*", FALSE, &w );
		soar_cGetWmeValue( w, gTheSoarPlayer->squareIds[i] ); 

		/*
		 * put all the leaves on the 'square' node
		 */
		tempStr[1] = '\0';

		tempStr[0] = '0' + i;
		soar_cAddWme( gTheSoarPlayer->squareIds[i], "^pos", tempStr, FALSE, &w );

		tempStr[0] = '0' + i/3;
		soar_cAddWme( gTheSoarPlayer->squareIds[i], "^row", tempStr, FALSE, &w );
		
		tempStr[0] = '0' + i%3;
		soar_cAddWme( gTheSoarPlayer->squareIds[i], "^col", tempStr, FALSE, &w );

		/* And don't forget to say what's in each square */
		if ( (Marker)(gBoard->d_board[i/3][i%3]) == MARKER_NONE ) 
			strcpy( tempStr, "EMPTY" );
		else 
			sprintf( tempStr, "%c", MarkerToChar( (Marker)(gBoard->d_board[i/3][i%3]))  );
	
		/*  content changes, so we store these timetags for later use */
		gTheSoarPlayer->squareContentTTs[i] = 
			soar_cAddWme( gTheSoarPlayer->squareIds[i], "^content", tempStr, FALSE, &w ); 
		
	}

}

/**
 * when moves are made, the board changes
 * This function is called each input-cycle
 * to determine which wmes need to be modified
 * We use the global data structure
 * gModifiedPositions for this.
 */
void update_agent_memory() {

	char buffer[10];
	int i, pos;
	psoar_wme w;

	for( i = 0; gModifiedPositions[i] != -1; i++ ) {

		pos = gModifiedPositions[i];
		
		/*  Remove the old content... */
		soar_cRemoveWmeUsingTimetag( gTheSoarPlayer->squareContentTTs[ pos ] );

		/* Figure out what the new content is */
		if ( (gBoard->d_board[pos/3][pos%3]) == MARKER_NONE ) 
			strcpy( buffer, "EMPTY" );
		else 
			sprintf( buffer, "%c", MarkerToChar( (gBoard->d_board[pos/3][pos%3]))  );
	
		/* Add the content wme */
		soar_cAddWme( gTheSoarPlayer->squareIds[ pos ], "^content", buffer, FALSE, &w );
		
		/* clean out the Modifications Stack */
		gModifiedPositions[i] = -1;
	}
}


/**
 * The print callback
 */
void tttPrint( agent *a, soar_callback_data data, soar_call_data cd ) {

	printf( "%s", (char *)cd );

}


/**
 *  The output function.
 *  Nothing too fancy here, and no real
 *  error checking ;)
 *  When the output-link is modified, 
 *  we check to make sure that there isn't a
 *  'complete' move on there.  We assume
 *  only one move structure is on the output-link
 *  at any time.
 */
void tttOutput( agent *a, soar_callback_data data, soar_call_data cd ) {
	io_wme *head, *move_wme, *pos_wme;
	wme *w;
	int position;
	char buffer1[20];
	char buffer2[20];


	switch( ((output_call_info *)cd)->mode ) {

	case MODIFIED_OUTPUT_COMMAND:
	case ADDED_OUTPUT_COMMAND:

	head = ((output_call_info *)cd)->outputs;

	/*  Look for a 'move' augmentation */
	move_wme = get_output_wme( "move", head );
	if ( !move_wme || get_output_wme( "status", head ) ) return;

    /* 
	 * Find the 'move' augmentation's id.  we need this
	 * to add 'status complete'
	 */
	soar_cGetWmeValue( move_wme, buffer2 );
	pos_wme = get_output_wme( "pos", head );

	/*
	 * Find the position to move into
	 */
	soar_cGetWmeValue( pos_wme, buffer1 );
	position = atoi( buffer1 );

	/*
	 * Place the marker there.  it better be legal */
	placeMarker( gBoard, gTheSoarPlayer->myMarker, position/3, position%3);
			
	/*
	 * ^status complete
	 */
	soar_cAddWme( buffer2, "^status", "complete", FALSE, (psoar_wme *)&w   );

	}
}

/**
 * The simple input function
 */
void tttInput( agent *a, soar_callback_data data, soar_call_data cd ) {

	switch ( (int) cd ) {

	case TOP_STATE_JUST_CREATED:
		initialize_agent_memory();
		printf( "Top state just created\n" );
		break;

	case NORMAL_INPUT_CYCLE:
		update_agent_memory();
		printf( "Updating...\n" );
		break;

	}
}


/**
 * Here we assume the agent will make a move in 1 decision
 */
void makeAgentMove( ) {

	soar_cRun( 1, TRUE, GO_DECISION, NO_SLOT );


}


/**
 * a handy utility to find a wme with the
 * specified attribute on the output-link
 */
io_wme *get_output_wme( char *attribute, io_wme *head ) {
  
  char *buff;
    /*
     *  Cycle through all wmes which were added to the output-link
     */
  while ( head != NULL ) {

	buff = soar_cGetWmeAttr( head, NULL );
	if ( !strcmp( buff, attribute ) ) {
	  free( buff );
	  return head;
	}

	free( buff );
	head = head->next;
  } 
  return NULL;
}
