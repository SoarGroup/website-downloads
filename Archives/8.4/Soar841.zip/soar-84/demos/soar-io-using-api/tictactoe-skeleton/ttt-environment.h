#ifndef INCLUDED_TTT_ENV_H
#define INCLUDED_TTT_ENV_H

#include <stdio.h>
#include <stdlib.h>


/*  Markers, X's O's and empty squares */
typedef enum Marker_enum { MARKER_NONE=0, MARKER_X, MARKER_O } Marker;


/*  The minimialist Board structure. (row, col) */
typedef struct Board_st {
	
	Marker d_board[3][3];

} Board;



/* All the functions a good agent needs */
extern Marker getMarkerAt( Board *b, int row,int col);
extern int placeMarker( Board *b, Marker m,int row,int col);
extern char MarkerToChar(Marker m);
extern int sourceProductionsFromFile( char *fname );

/* the Board.  This is where the game takes place */
extern Board *gBoard;

/* 
  This list is initially set to -1 (empty)
  Each time placeMarker() is called,
  the first non-empty element (i.e. != -1 )
  is set to the position that the marker
  was placed in (i.e. row*3 + col )
  This list builds up until some outside
  force empties it by resetting the elements
  to -1 
 */
extern int gModifiedPositions[10];

#endif // INCLUDED_TTT_ENV_H