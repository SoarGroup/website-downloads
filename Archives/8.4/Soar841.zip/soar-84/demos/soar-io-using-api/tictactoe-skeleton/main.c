#include "ttt-environment.h"
#include "soar-player.h"
#include <stdio.h>

Board *gBoard;

extern Board *createBoard();
extern int IsCatGame();
extern Marker CheckForWinner( Board *b );
extern void Print( Board *b );



int main() {

	Marker won, turn = MARKER_X;
	int x,y;
	int validMove;

	gBoard = createBoard();
	createSoarPlayer( MARKER_O );
	
	while(!IsCatGame(gBoard) && (won = CheckForWinner(gBoard)) == MARKER_NONE) {
		Print(gBoard);
		if(turn == MARKER_O) {
			printf( "Soar is moving...\n" );
			makeAgentMove( );
		}
		else {
			validMove = 0;
			while(!validMove) {
				printf( "Enter your move %c <row> <col>: ", MarkerToChar(turn) ); 
				fscanf( stdin, "%d %d", &x, &y );
				validMove = placeMarker( gBoard, turn,x,y);

				if ( !validMove ) {
					printf( "That is not a valid move, try again.\n" );
					
				}
			}
		}
		turn = (turn == MARKER_X) ? MARKER_O : MARKER_X;
	}
	Print(gBoard);
	if(IsCatGame(gBoard))
		printf( "Cat's game\n" );
	else
		printf( "%c won!\n", MarkerToChar(won));

return 0;
}
