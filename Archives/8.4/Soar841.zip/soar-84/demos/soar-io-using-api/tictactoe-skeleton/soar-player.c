#include "soar-player.h"
#include "soar_ecore_api.h"


SoarPlayer *gTheSoarPlayer;


io_wme *get_output_wme( char *attribute, io_wme *head );

/**
	Create the Soar Agent to Play tic-tac-toe.
	Soar is completely un-initialized when this
	function is called.  We do all the initialization
	here and then set up the global pointer
	(gTheSoarPlayer) to keep track of the environment
	side agent info
*/
  
void createSoarPlayer( Marker myMarker ) {

		/* This function is called somewhere in main() 
		   to create the agent to play tictactoe.
		   It is called before any other reference to agents or
		   Soar has been made, so all initialization must take place
		   here.
		*/

}


/** An output function stub */
void ttt_output_fn( agent *a, soar_callback_data data, soar_call_data cd ) {
	io_wme *head;

	head = ((output_call_info *)cd)->outputs;

	switch( ((output_call_info *)cd)->mode ) {

	case MODIFIED_OUTPUT_COMMAND:
	case ADDED_OUTPUT_COMMAND:
	}
}

/** An input function stub */
void ttt_input_fn( agent *a, soar_callback_data data, soar_call_data cd ) {

	switch ( (int) cd ) {

	case TOP_STATE_JUST_CREATED:
	case NORMAL_INPUT_CYCLE:

	}
}

	

void makeAgentMove( ) {

	/* Do what it takes to make the agent move! */
}


/**
 * a handy utility to find a wme with the
 * specified attribute on the output-link
 */
io_wme *get_output_wme( char *attribute, io_wme *head ) {
  
  char *buff;
    /*
     *  Cycle through all wmes which were added to the output-link
     */
  while ( head != NULL ) {

	buff = soar_cGetWmeAttr( head, NULL );
	if ( !strcmp( buff, attribute ) ) {
	  free( buff );
	  return head;
	}

	free( buff );
	head = head->next;
  } 
  return NULL;
}
