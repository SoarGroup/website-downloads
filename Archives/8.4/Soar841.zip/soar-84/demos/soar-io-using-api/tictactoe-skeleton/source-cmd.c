#include "soarapi.h"

#define MAX_TOKENS 16
#define MAX_LINE_LENGTH 1024


/**
 * Most of this code is stolen from soar/new-unix-interface/parsing.c
 */


int tokenizeString( char *input, int *ntokens, char ***tokens, 
		    char *token_terminator, soarResult *res );

char *getProductionFromFile( int (*readCharacter)(FILE *), FILE *f, 
			  bool *eof_reached );

int loadProduction( char *command );





int sourceProductionsFromFile( char *fname ) {

  FILE *f;
  bool eof_reached;

  f = fopen( fname, "r" );
  
  if ( !f ) {
    return SOAR_ERROR;
  }

  eof_reached = FALSE;
  while( !eof_reached ) {
    loadProduction( getProductionFromFile( fgetc,f,  &eof_reached ) );
  }
  
  fclose( f );
  return SOAR_OK;
}
  





/*  
 * execute a command.
 *
 *  The command is expected to be a string suitable for passing to
 *  tokenizeString.  The first word is interpreted as the command name
 *  and the remaining words are interpreted as arguments to that command
 *
 */
int loadProduction( char *command ) {

  char **tokens;
  int ntokens;
  char token_terminator;
  soarResult res;  

  init_soarResult( res );

  token_terminator = '\0';

  /*
   *  Attempt to break the command into tokens.  If its is unparsable,
   *  i.e. a token is unterminated, the token_terminator character
   *  will be non-null. 
   */
  tokenizeString( command, &ntokens, &tokens, &token_terminator, &res );


  if ( token_terminator ) {    
    print( "\n\nError: Token unterminated...\n" );
    return SOAR_ERROR;
  }
  
  /*
   *  Check for no-op.
   */
  if ( ntokens < 1 ) return SOAR_OK;
  
  
  /*
   *  the first token is the command name.  Make sure it is 'sp'
   */
  if ( strcmp( tokens[0], "sp" ) ) {
	  print( "This ('%s') is not a production!\n", tokens[0] );
	  return SOAR_ERROR;
  }
  
  
  /*
   *  Otherwise, load the production body
   */
  if ( soar_Sp( ntokens, tokens, &res ) == SOAR_ERROR ) {
    print( "Error loading production\n");
  }
  else if ( *res.result ) {
	print ( "   %s\n", res.result );
  }

  
  return SOAR_OK;
}



/*
 *  This function performs the majority of the work by breaking a
 *  single line up into tokens.  The line is expected to contain a
 *  single command and its arguments, so nothing too complex should be
 *  passed to this function. More complex input can be given to
 *  getCommandFromFile which deals with multiple lines, and other
 *  oddities.  A simple parsing method is used which is similar to that
 *  done by the Tcl shell.
 *  
 *  Basically, a line is split into words (words being alphanumeric
 *  strings seperated by whitespace).  
 *
 *  Words within double quotes are considered a single token as are
 *  words within curly braces.  
 *
 */

int tokenizeString( char *input, int *ntokens, char ***tokens, 
		     char *token_terminator, soarResult *res ) {


  char *token_begin, *token_end;        /* The beginning and end of a token */
  char *current;                        /* The current character */
  char *copy;
  int brace_level;                      /* The depth of nested braces */

  current = input;

#ifdef DEBUG
    printf( "Token Terminator = %c\n", *token_terminator);
    printf( "Tokenizing: '%s'\n", input );
#endif

  /*
   *  A command line can have at most MAX_TOKENS... beware.
   */
  *tokens = (char **)malloc( MAX_TOKENS * sizeof(char *) );
  *ntokens = 0;


  brace_level = 0;
  
  while( *current ) {

    /* find token begin */
    while ( !(*token_terminator) && isspace( *current ) ) {
      current++;
      
      if ( *current == '{' ) {
	*token_terminator = '}';
	
	/* Strip top level braces */
	current++;
	brace_level++;
      }
      else if( *current == '"' ) {
	*token_terminator = '"';
	
	/* Strip top level quotes */
	current++;       	
      }
    }
    
    token_begin = current;

#ifdef DEBUG
     printf( "Token %d", *ntokens ); 
#endif

    if ( *ntokens >= MAX_TOKENS ) {
      setSoarResultResult( res,
         "Too many tokens in string.  Exceeded maximum of %d\n", MAX_TOKENS );
      return SOAR_ERROR;
    }
  
    /* find token end */
    if ( *token_terminator ) {
      
      if ( *token_terminator == '}' ) {
	while( *current) {
	  if ( *current == '{' )  brace_level++;
	  if ( *current == '}' ) {
	    brace_level--;
	    if ( !brace_level ) break;
	  }
	  current++;	  
	}
      }
      else {
	while( *current && *current != *token_terminator ) current++;
      }
	    
      /* found terminator */
      if ( *current ) {
	
	/* Stip off top level token terminator */
	token_end = current;
	
	current++;
	*token_terminator = '\0';
      }
    }
    else {
      
      while( *current && !isspace( *current ) )
	current++;
      
      token_end = current;
    }
    
    
    
    if ( token_begin != token_end ) {
      
      /* Allocate memory for token storage */
      (*tokens)[*ntokens] = (char *)malloc( (token_end - token_begin + 1) * 
					    sizeof( char ) );
      

      copy = (*tokens)[*ntokens];
      while( token_begin != token_end ) {
	*copy++ = *token_begin++;
      }
      *copy = '\0';

      (*ntokens)++;
    }    
  }

#ifdef DEBUG
  {
    int i;
    for( i = 0; i < (*ntokens); i++ ) {
      printf( "Token %d: '%s'\n", i , (*tokens)[i] );
    }
  };

  printf( "Token Terminator = %c\n", *token_terminator);
  fflush( stdout );
#endif 

  /* HP: non-void function should return a value */
  return( SOAR_OK );
}










char *getProductionFromFile( int (*readCharacter)(FILE *), FILE *f, 
			  bool *eof_reached ) {

  static char input_str[MAX_LINE_LENGTH];
  char *input; 
  int brace_level;
  int inQuotedString;

  int  inputInt;

  inQuotedString = 0;
  brace_level = 0;
  
  *eof_reached = FALSE;
  
  input = input_str;
  while ( inputInt = (*readCharacter)(f) ) {

    
    if ( inputInt == EOF ) {
      *eof_reached = TRUE;
      *input = '\0';
      break;
    }

    /* convert to char */
    *input = (char) inputInt;

    if ( *input == '#' ) {

      /* consume until end of line, without incrementing */
      while( inputInt = (*readCharacter)(f) ) {
	
	/* convert to char */
	*input = (char) inputInt;
	
	if ( (inputInt == EOF) || (*input == '\n') || (*input == '\0') ) {	 
	  *input = '\0';
	  break;
	}
      }
      continue;

    }
 
    /* Look for end of line */
    if ( *input == '\n' || *input == ';' ) {
      *input = '\n';
      if ( !inQuotedString && brace_level == 0 ) { 
	*input = '\0';
	break;
      }
    }
    else if ( *input == '"' ) {
      inQuotedString = !inQuotedString;
    }
    else if ( *input == '{' ) {
      brace_level++;
    }
    else if ( *input == '}' ) {
      brace_level--;
      
      if ( brace_level < 0 ) {
	print( "\n extra characters after close-brace\n" );
	
	
	/* invalidate command & reset */		
	input_str[0] = '\0';
	brace_level = 0;
	inQuotedString = 0;
	
	break;
      }
    }
    
    input++;
    
    
  }

  /*  print( "Get Command Returns '%s'\n", input_str ); */
  return input_str;
  
}
	





