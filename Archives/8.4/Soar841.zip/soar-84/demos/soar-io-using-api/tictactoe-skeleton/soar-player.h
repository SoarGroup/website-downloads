
#ifndef SOAR_PLAYER_H
#define SOAR_PLAYER_H

#include "ttt-environment.h"

typedef struct soar_player_st {

	Marker myMarker;
	char squareIds[9][10];
	unsigned long squareContentTTs[9];

} SoarPlayer;



extern SoarPlayer *gTheSoarPlayer;

void createSoarPlayer( Marker myMarker );
void makeAgentMove( );

#endif
