#include "ttt-environment.h"


#define false 0
#define true 1



int gModifiedPositions[10];



/**
 * Board Control Functions
 */

void clearBoard( Board *b ) {
	int i,j;

	for( i = 0; i < 3; ++i) 
		for( j = 0; j < 3; ++j)
			b->d_board[i][j] = MARKER_NONE;

	for( i = 0; i < 10; i++ ) gModifiedPositions[i] = -1;
}


Board *createBoard() {

	Board *b = malloc( sizeof( Board ) );
		
	clearBoard( b );
	return b;
}


int placeMarker( Board *b, Marker m,int row,int col) {
	int i;

	if(row >= 0 && row <= 2 && col >= 0 && col <= 2 && b->d_board[row][col] == MARKER_NONE) {
		b->d_board[row][col] = m; 
		for( i = 0; gModifiedPositions[i] != -1; i++ );
		gModifiedPositions[i] = row * 3 + col;
		return 1;
	}
	return 0;
}

Marker getMarkerAt( Board *b, int row,int col) {
	if(row >= 0 && row <= 2 && col >= 0 && col <=2) {
		return b->d_board[row][col];
		
	}
	return -1;
}


/**
 * Utility & Game Control Functions
 */

char MarkerToChar(Marker m) {
	switch(m) {
		case MARKER_NONE:
			return ' ';
		case MARKER_X:
			return 'X';
		case MARKER_O:
			return 'O';
		default:
			return '?';
	}
}


Marker CheckForWinner( Board *board) {
	
	// Check Horizontals
	if(getMarkerAt( board, 0,0) == getMarkerAt( board, 0,1) && getMarkerAt( board, 0,0) == getMarkerAt( board, 0,2) && getMarkerAt( board, 0,0) != MARKER_NONE)
		return getMarkerAt( board, 0,0);
	else if(getMarkerAt( board, 1,0) == getMarkerAt( board, 1,1) && getMarkerAt( board, 1,0) == getMarkerAt( board, 1,2) && getMarkerAt( board, 1,0) != MARKER_NONE)
		return getMarkerAt( board, 1,0);
	else if(getMarkerAt( board, 2,0) == getMarkerAt( board, 2,1) && getMarkerAt( board, 2,0) == getMarkerAt( board, 2,2) && getMarkerAt( board, 2,0) != MARKER_NONE)
		return getMarkerAt( board, 2,0);
	// Check Verticals
	else if(getMarkerAt( board, 0,0) == getMarkerAt( board, 1,0) && getMarkerAt( board, 0,0) == getMarkerAt( board, 2,0) && getMarkerAt( board, 0,0) != MARKER_NONE)
		return getMarkerAt( board, 0,0);
	else if(getMarkerAt( board, 0,1) == getMarkerAt( board, 1,1) && getMarkerAt( board, 0,1) == getMarkerAt( board, 2,1) && getMarkerAt( board, 0,1) != MARKER_NONE)
		return getMarkerAt( board, 0,1);
	else if(getMarkerAt( board, 0,2) == getMarkerAt( board, 1,2) && getMarkerAt( board, 0,2) == getMarkerAt( board, 2,2) && getMarkerAt( board, 0,2) != MARKER_NONE)
		return getMarkerAt( board, 0,2);
	// Check Diagonals
	else if(getMarkerAt( board, 0,0) == getMarkerAt( board, 1,1) && getMarkerAt( board, 0,0) == getMarkerAt( board, 2,2) && getMarkerAt( board, 0,0) != MARKER_NONE)
		return getMarkerAt( board, 0,0);
	else if(getMarkerAt( board, 0,2) == getMarkerAt( board, 1,1) && getMarkerAt( board, 0,2) == getMarkerAt( board, 2,0) && getMarkerAt( board, 0,2) != MARKER_NONE)
		return getMarkerAt( board, 0,2);
	else
		return MARKER_NONE;
}

int IsCatGame( Board* board) {
	int i,j;

	for( i = 0; i < 3; ++i) 
		for( j = 0; j < 3; ++j)
			if(getMarkerAt( board, i,j) == MARKER_NONE)
					return false;
	return CheckForWinner(board) == MARKER_NONE;
}

void Print( Board* board) {
	int i,j;
	
	printf( "\n\n" );
	for( i = 0; i < 3; ++i) {
		for( j = 0; j < 3; ++j) {
			printf( "%c", MarkerToChar(getMarkerAt( board, i,j) ) );
			if(j != 2)
				printf( "|" ); 
		}
		printf( "\n" );
		if(i != 2)
			printf( "-----\n" );
	}
	printf( "\n" );
}

