/*
 * =======================================================================
 *  File:  soarAgent.c
 *
 * This file includes the routines for creating, initializing and destroying
 * Soar agents.  It also includes the code for the "Tcl" rhs function
 * which allows Soar agents to call Tcl functions on the rhs of productions.
 *
 * =======================================================================
 *
 *
 * Copyright (c) 1995-1999 Carnegie Mellon University,
 *                         University of Michigan,
 *                         University of Southern California/Information
 *                         Sciences Institute.
 *
 * The Soar consortium proclaims this software is in the public domain, and
 * is made available AS IS.  Carnegie Mellon University, The University of 
 * Michigan, and The University of Southern California/Information Sciences 
 * Institute make no warranties about the software or its performance,
 * implied or otherwise.
 * =======================================================================
 */

#include "soar.h"
#include "scheduler.h"



#if defined(WIN32)
#include <direct.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#endif /* WIN32 */

#if defined(MACINTOSH)
#include <stdlib.h>
#include <string.h>
#include <time.h>
#endif /* MACINTOSH */

#include "soarCommands.h"

extern int agent_counter;


extern Tcl_Interp *tcl_soar_agent_interpreters[MAX_SIMULTANEOUS_AGENTS];

/* --------------------------------------------------------------------
                                Tcl 

   Sends a string to the Tcl interpreter
-------------------------------------------------------------------- */

Symbol *tcl_rhs_function_code (list *args) {
  Symbol *arg;
  growable_string script_to_run;
  int result;

  if (!args) {
    print ("Error: 'tcl' function called with no arguments.\n");
    return NIL;
  }

  script_to_run = make_blank_growable_string();

  for ( ; args != NIL; args = args->rest) 
    {
      arg = args->first;
    /* --- Note use of FALSE here--print the symbol itself, not a rereadable
       version of it --- */
      add_to_growable_string(&script_to_run,
                             symbol_to_string (arg, FALSE, NIL));
    }

  result = Tcl_GlobalEval(tcl_soar_agent_interpreters[current_agent(id)], 
			  text_of_growable_string(script_to_run));

  if (result != TCL_OK)
    {
      print("Error: Failed RHS Tcl evaluation of \"%s\"\n", 
	    text_of_growable_string(script_to_run));
      print("Reason: %s\n", tcl_soar_agent_interpreters[current_agent(id)]->result);
      control_c_handler(0);
      free_growable_string(script_to_run);
      return NIL;
    }

  free_growable_string(script_to_run);
  
  return make_sym_constant(tcl_soar_agent_interpreters[current_agent(id)]->result);
}
