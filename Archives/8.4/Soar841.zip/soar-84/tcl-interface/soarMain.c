/* 
 * main.c --
 *
 *	Main program for Tcl shells and other Tcl-based applications.
 *
 * Copyright (c) 1993 The Regents of the University of California.
 * Copyright (c) 1994-1995 Sun Microsystems, Inc.
 * Copyright (c) 1995 Carnegie Mellon University, University of Michigan,
 *                    University of Southern California/Information Sciences
 *                    Institute.
 *
 * See the file "license.terms" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * The Soar consortium proclaims this software is in the public domain, and
 * is made available AS IS.  Carnegie Mellon University, The University of 
 * Michigan, and The University of Southern California/Information Sciences 
 * Institute make no warranties about the software or its performance, implied
 * or otherwise.
 */

#if defined(WIN32)
#include <windows.h>
#endif /* WIN32 */

#include <errno.h>
#include <stdio.h>
#include <string.h>
#include "soar.h"
#include "soarCommandUtils.h"
#include "soar_core_api.h"

extern void cb_tclSoar_NewAgent( soar_callback_agent a,
			  soar_callback_data d,
			  soar_call_data c );

/*
 * Declarations for various library procedures and variables (don't want
 * to include tkInt.h or tkPort.h here, because people might copy this
 * file out of the Tk source directory to make their own modified versions).
 * Note:  "exit" should really be declared here, but there's no way to
 * declare it without causing conflicts with other definitions elsewher
 * on some systems, so it's better just to leave it out.
 */

extern int		isatty _ANSI_ARGS_((int fd));
extern int		read _ANSI_ARGS_((int fd, char *buf, size_t size));

/*
 * Global variables used by the main program:
 */

RegisteredInterp * mainInterp = NULL;
                                /* The current active top-level interp. */
static Tcl_Interp *interp;	/* Interpreter for this application. */
static int tty;			/* Non-zero means standard input is a
				 * terminal-like device.  Zero means it's
				 * a file. */
static char errorExitCmd[] = "exit 1";
static char * process_name;     /* Name used to start this process */

/*
 * Command-line options:
 */

static option_table options;    /* Table of interpreter creation options */



/**
 * Called when the DLL is first loaded into memory.
 */

#if defined(WIN32)
BOOL APIENTRY
DllMain(hInst, reason, reserved)
    HINSTANCE hInst;		/* Library instance handle. */
    DWORD reason;		/* Reason this function is being called. */
    LPVOID reserved;		/* Not used. */
{
        if (reason == DLL_PROCESS_ATTACH) {
		init_soar();

		soar_cAddGlobalCallback( GLB_AGENT_CREATED,
							 cb_tclSoar_NewAgent,
							 NIL, NIL,
							"new-agent" );
	}
	return TRUE;
}
#endif /* WIN32 */




/*
 *----------------------------------------------------------------------
 *
 * Soar_UseIPC --
 *
 *	This procedure is called to determine if IPCs are 
 *	to be used for Tk interpreters.  Determines whether they
 *      are registered with the X server.
 *
 * Results:
 *	0 if IPCs disabled (default), 1 if enabled.
 *
 * Side effects:
 *	None.
 *
 *----------------------------------------------------------------------
 */

int
Soar_UseIPC (void)
{
  /* fprintf(stderr, "in Soar_UseIPC, value = %d\n",options.ipc_enabled); */
  return options.ipc_enabled;
}
  


