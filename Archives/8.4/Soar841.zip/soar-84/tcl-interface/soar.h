/*
 * soar.h --
 *
 *      This header file describes the externally-visible facilities
 *      of the Soar system interface to Tcl.
 *
 *
 * Copyright (c) 1995-1999 Carnegie Mellon University,
 *                         University of Michigan,
 *                         University of Southern California/Information
 *                         Sciences Institute.
 *
 * The Soar consortium proclaims this software is in the public domain, and
 * is made available AS IS.  Carnegie Mellon University, The University of 
 * Michigan, and The University of Southern California/Information Sciences 
 * Institute make no warranties about the software or its performance,
 * implied or otherwise.
 * =======================================================================
 */


#ifndef SOAR_H_INCLUDED
#define SOAR_H_INCLUDED

#include <tcl.h>


#include <soarkernel.h>
#include <callback.h>

/*----------------------------------------------------------------------*/

/* ARGC/ARGV Processing structures and functions.                       */

/*
 * Structure used to specify how to handle argv options.
 */

typedef struct {
    char *key;		/* The key string that flags the option in the
			 * argv array. */
    int type;		/* Indicates option type;  see below. */
    char *src;		/* Value to be used in setting dst;  usage
			 * depends on type. */
    char *dst;		/* Address of value to be modified;  usage
			 * depends on type. */
    char *help;		/* Documentation message describing this option. */
} Soar_ArgvInfo;


/*
 * Legal values for the type field of a Soar_ArgvInfo: see the user
 * documentation for details.
 */

#define SOAR_ARGV_CONSTANT		1
#define SOAR_ARGV_STRING		2
#define SOAR_ARGV_REST			3
#define SOAR_ARGV_HELP			4
#define SOAR_ARGV_AGENT			5
#define SOAR_ARGV_TCLSH			6
#define SOAR_ARGV_WISH			7
#define SOAR_ARGV_END			8

/*
 * Flag bits for passing to Soar_ParseArgv:
 */

#define SOAR_ARGV_NO_LEFTOVERS		0x1

typedef struct {
  int start_argv;
  int end_argv;
} soar_argv_list;

typedef struct {
  int   tk_enabled;
  int   ipc_enabled;
  int   synchronize;
  int   verbose;
  char *path;
  char *display;
  char *fileName;
  char *geometry;
  soar_argv_list names;
} option_table;

extern int Soar_ParseArgv (int * argcPtr, char ** argv, 
			   Soar_ArgvInfo * argTable, int flags, 
			   int * srcIndex, int * dstIndex,
			   int * interp_type, int * options_done);

/*----------------------------------------------------------------------*/

/* 
 * The following structure is used to keep track of the interpreters 
 * registered by this process.
 */

typedef struct RegisteredInterp {
    Tcl_Interp *interp;		/* Interpreter associated with name.  NULL
				 * means that the application was unregistered
				 * or deleted while a send was in progress
				 * to it. */
    agent * agentPtr;           /* Agent associated with name. */
    struct RegisteredInterp *nextPtr;
				/* Next in list of names associated
				 * with interps in this process.
				 * NULL means end of list. */
} RegisteredInterp;

extern RegisteredInterp *registry;
				/* List of all interpreters
				 * registered by this process. */

extern RegisteredInterp * mainInterp;  
                                /* The current active top-level interp. */
/*----------------------------------------------------------------------*/

typedef struct Soar_TextWidgetPrintData {
    Tcl_Interp *interp;		/* Interpreter containing text widget */
    char * text_widget;         /* Text widget to print in. */
  } Soar_TextWidgetPrintData;

/*----------------------------------------------------------------------*/

extern void Soar_AgentInit (agent * a);
extern void Soar_AppendResult (agent *, soar_callback_data, soar_call_data);
extern void Soar_DestroyRegisterEntry (RegisteredInterp * riPtr);
extern void Soar_DiscardPrint (agent *, soar_callback_data, soar_call_data);
extern void Soar_FClose (FILE *);
extern void Soar_FreeTextWidgetPrintData (Soar_TextWidgetPrintData * data);
extern RegisteredInterp * Soar_GetRegisteredInterp (char * name);
extern RegisteredInterp * Soar_GetRegisteredInterpByInterp (Tcl_Interp * interp);
extern void Soar_InstallCommands(agent * new_agent);
extern void Soar_LinkInterpVars2Agent(Tcl_Interp * interp, agent * new_agent);
extern void Soar_Log (agent *, char *);
extern void Soar_LogAndPrint (agent *, char *);
extern void Soar_Main (int argc, char ** argv);
extern RegisteredInterp * Soar_MakeRegisterEntry (Tcl_Interp * interp, agent * agentPtr);
extern Soar_TextWidgetPrintData *
       Soar_MakeTextWidgetPrintData (Tcl_Interp * interp, char * widget_name);
extern int  Soar_NameInRegistry (char * name);
extern void Soar_Print (agent *, char *);
extern void Soar_PrintToFile (agent *, soar_callback_data, soar_call_data);
extern void Soar_PrintToChannel (agent *, soar_callback_data, soar_call_data);
extern void Soar_PrintToTextWidget (agent *, soar_callback_data, 
				    soar_call_data);
/* extern char *Soar_Read (agent *, char *, int); /* kjh(CUSP-B10)*/
/* extern void Soar_RecordToFile (agent *, soar_callback_data, soar_call_data); /* kjh(CUSP-B10)*/
/* extern void Soar_ReadFromFile (agent *, soar_callback_data, soar_call_data); /* kjh(CUSP-B10)*/
/* extern void Soar_EndReplay(agent *); /* kjh(CUSP-B10)*/
/* Soar_PrintToTclProc RMJ 7-1-97 */
extern void Soar_PrintToTclProc (agent *, soar_callback_data, 
				    soar_call_data);
extern void Soar_RegisterArgv (int argc, char ** argv, 
			       RegisteredInterp * Rinterp);
extern void Soar_SelectGlobalInterpByInterp (Tcl_Interp * interp);
extern int  Soar_UseIPC ();

/* In tkText.c */
EXTERN void Tk_PrintToTextWidget _ANSI_ARGS_((Tcl_Interp *interp,
					      ClientData data,
					      ClientData call_data));

#endif /* Recursive include guard */
