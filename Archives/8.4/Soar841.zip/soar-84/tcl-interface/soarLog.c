/*
 * =======================================================================
 *  File:  soarLog.c
 *
 * Interface routines to handle printing and logging for agents.
 *
 * =======================================================================
 *
 *
 * Copyright (c) 1995-1999 Carnegie Mellon University,
 *                         University of Michigan,
 *                         University of Southern California/Information
 *                         Sciences Institute.  All rights reserved.
 *
 * The Soar consortium proclaims this software is in the public domain, and
 * is made available AS IS.  Carnegie Mellon University, The University of 
 * Michigan, and The University of Southern California/Information Sciences 
 * Institute make no warranties about the software or its performance,
 * implied or otherwise.
 * =======================================================================
 */

#include <string.h>
#include "soar.h"

extern Tcl_Interp *tcl_soar_agent_interpreters[MAX_SIMULTANEOUS_AGENTS];

void
Soar_Print (the_agent, str)
     agent * the_agent;
     char * str;
{
  soar_invoke_first_callback(the_agent, PRINT_CALLBACK, (ClientData) str);
}

void
Soar_Log (the_agent, str)
     agent * the_agent;
     char * str;
{
  soar_invoke_first_callback(the_agent, LOG_CALLBACK, (ClientData) str);
}

void
Soar_LogAndPrint (the_agent, str)
     agent * the_agent;
     char * str;
{
  Soar_Log(the_agent, str);
  Soar_Print(the_agent, str);
}

void
Soar_PrintToFile (the_agent, data, call_data)
     agent * the_agent;	
     soar_callback_data data;
     soar_call_data call_data;
{
  FILE * f = (FILE *) data;
  fputs((char *) call_data, f);
}

void
Soar_PrintToChannel(the_agent, data, call_data)
	agent * the_agent;
	soar_callback_data data;
	soar_call_data call_data;
{
	Tcl_Channel channel = (Tcl_Channel) data;
	Tcl_Write(channel, (char*) call_data, strlen((char*) call_data));
	Tcl_Flush(channel);
}

void
Soar_PrintToTextWidget (the_agent, data, call_data)
     agent * the_agent;	
     soar_callback_data data;
     soar_call_data call_data;
{
	Soar_TextWidgetPrintData * print_data = (Soar_TextWidgetPrintData *) data;

	char buf[1024];
	sprintf(buf, "%s insert end \"%s\" ", print_data->text_widget, (char*) call_data);
	Tcl_Eval(tcl_soar_agent_interpreters[the_agent->id], buf);

        /* RMJ 7-1-97 */
        sprintf(buf, "%s see end", print_data->text_widget);
	Tcl_Eval(tcl_soar_agent_interpreters[the_agent->id], buf);
	Tcl_Eval(tcl_soar_agent_interpreters[the_agent->id], "update");
}

/* RMJ 7-1-97 */
/* Uses text_widget as procedure name and passes the string to the proc */
/* Modified 8-19-98 to surround string with dbl quotes instead of braces
 * so productions are printed properly.  (productions have braces in
 * them and any line with braces was getting dropped) kjc
 */
void
Soar_PrintToTclProc (the_agent, data, call_data)
     agent * the_agent;	
     soar_callback_data data;
     soar_call_data call_data;
{
	Soar_TextWidgetPrintData * print_data = (Soar_TextWidgetPrintData *) data;

	char buf[1024];
	/*    printf("args:   %s<>%s\n", print_data->text_widget, (char*) call_data); */
	sprintf(buf, "%s \"%s\" ", print_data->text_widget, (char*) call_data);
	/*    printf("here's the buf: >> %s\nendbuf\n",buf);  */

	Tcl_Eval(tcl_soar_agent_interpreters[the_agent->id], buf);
	Tcl_Eval(tcl_soar_agent_interpreters[the_agent->id], "update");
}

void
Soar_DiscardPrint (the_agent, data, call_data)
     agent * the_agent;
     soar_callback_data data;
     soar_call_data call_data;
{
  /* No need to do anything */
}

void
Soar_AppendResult (the_agent, data, call_data)
     agent * the_agent;
     soar_callback_data data;
     soar_call_data call_data;
{
  Tcl_AppendResult(tcl_soar_agent_interpreters[the_agent->id], 
	           (char *) call_data, 
	           (char *) NULL);
}

void
Soar_FClose (FILE * f)
{
  fclose(f);
}
