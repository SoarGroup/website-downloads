/*
 * =======================================================================
 *  File:  soarCommands.h
 *
 * soar_install_commands is called when agents are initialized to
 * create the Soar command set.
 *
 * =======================================================================
 *
 *
 * Copyright (c) 1995-1999 Carnegie Mellon University,
 *                         University of Michigan,
 *                         University of Southern California/Information
 *                         Sciences Institute.
 *
 * The Soar consortium proclaims this software is in the public domain, and
 * is made available AS IS.  Carnegie Mellon University, The University of 
 * Michigan, and The University of Southern California/Information Sciences 
 * Institute make no warranties about the software or its performance,
 * implied or otherwise.
 * =======================================================================
 */
/*----------------------------------------------------------------------
 *
 * PLEASE NOTE!  Only functions implementing commands should appear
 * in this file.  All supporting functions should be placed in 
 * soarCommandUtils.c.
 *
 *----------------------------------------------------------------------
 */

#include <soarkernel.h>

extern void soar_install_commands (agent * the_agent);
