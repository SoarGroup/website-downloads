package edu.umich.soar.visualsoar.parser;

public final class ForcedUnaryPreference extends PreferenceSpecifier {
	public ForcedUnaryPreference(int type) {
		super(type);
	}
}
