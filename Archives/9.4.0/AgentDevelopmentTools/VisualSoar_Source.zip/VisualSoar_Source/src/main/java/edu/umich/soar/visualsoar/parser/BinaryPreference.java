package edu.umich.soar.visualsoar.parser;

public final class BinaryPreference extends PreferenceSpecifier {
	public BinaryPreference(int type,RHSValue rhs) {
		super(type,rhs);
	}
}
