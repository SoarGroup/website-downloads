/**
 *
 * Copyright (c) 1996 Sun Microsystems, Inc.
 *
 * Use of this file and the system it is part of is constrained by the
 * file COPYRIGHT in the root directory of this system.
 *
 */

/*
 * NOTE: This class is now deprecated.  Please use the method "mainProgram"
 * in class "Main" instead.
 */

package COM.sun.labs.javacc;

public class MacMain {

  public static void main(String args[]) throws Exception {
    Main.mainProgram(args);
  }

}
