#pragma once

// C RunTime Header Files
#include <memory.h>
#include <tchar.h>

#include "resource.h"
