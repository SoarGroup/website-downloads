ReadMe
of the Tower-Of-Hanoi Soar System
Feb 20, 94


This directory contains:

  --  (a) README, this file;
  --  (b) tower-of-hanoi.soar, the Soar system; and
  --  (c) probs, a directory of various problems to solve from the domain of (b).

For the task domain, see the header of the file (b).

When first loaded, (b) attempts to solve prob.3d.1 (see the directory probs).

To try another problem, just source a prob file from the directory probs and
do init-soar. 

Note. This Soar system implements what Herbert A. Simon calls "a sophisticated
perceptual strategy" for the tower-of-hanoi task, but it does not produce or
acquire that strategy.  

