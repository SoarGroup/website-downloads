This directory contains various demo programs for Soar 7.  More detail
about the directories are:

 analogy            - The code for the deliberate analogy example
 blocks-world       - The code for the Blocks world example
 eight_puzzle       - The code for the eight puzzle demo/example
 farmer             - The code for the farmer puzzle example
 kab                - The code for the Keys and Boxes example
 missionaries       - The code for the Missionaries and Cannibals example
 safe-stack         - The code for the Safe Stack examples
 towers-of-hanoi    - The code for the Towers of Hanoi examples
 waterjug           - The code for the Water Jug example
