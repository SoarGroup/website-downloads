# eight-puzzle/README
# John Laird
# October 27, 2003
# 
# eight-puzzle.soar
#    Straight forward implementation of eight-puzzle
#    Uses look-ahead search to solve puzzle with simple
#    evaluation function - demonstrates chunking.
#    Look-ahead search is implemented in ../default/selection.soar
#
# eight-puzzle.tcl
#    Simple graphic depiction of eight puzzle states as 
#    problem is solved.  Source this file instead of eight-puzzle.soar
#    if you want the graphical interface.

