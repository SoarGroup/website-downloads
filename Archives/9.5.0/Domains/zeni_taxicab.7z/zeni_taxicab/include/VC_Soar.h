#ifndef VC_SOAR_H
#define VC_SOAR_H

#include <Soar_Agent.h>
#include "Input_Link.h"
#include "VC_State.h"

void vc_update_event_handler(sml::smlUpdateEventId, void *user_data_ptr, sml::Kernel* kernel_ptr, sml::smlRunFlags);

class VC_Soar {
  friend void vc_update_event_handler(sml::smlUpdateEventId, void *user_data_ptr, sml::Kernel* kernel_ptr, sml::smlRunFlags);

  /// Disabled (No Implementation)
  VC_Soar(const VC_Soar &);
  VC_Soar & operator=(const VC_Soar &);

  /* TOH_Game will create the default 'Soar_Kernel()' if a kernel is not provided.
   * TOH_Game will take care of the deletion of the given kernel if one is provided.
   */
  VC_Soar(VC_State &state,
          const Zeni::String &agent_productions,
          const float &default_temp,
          const float &default_temp_reduction_rate,
          const float &default_temp_lower_bound,
          const int &port = 2914 /*sml::Kernel::kDefaultsmlPort*/,
          sml::Kernel * const kernel = 0);

public:
  static VC_Soar * local_trial(VC_State &state,
                               const Zeni::String &agent_productions,
                               const float &default_temp,
                               const float &default_temp_reduction_rate,
                               const float &default_temp_lower_bound,
                               const int &port = 2914 /*sml::Kernel::kDefaultsmlPort*/);
  static VC_Soar * remote_trial(VC_State &state,
                                const Zeni::String &agent_productions,
                                const float &default_temp,
                                const float &default_temp_reduction_rate,
                                const float &default_temp_lower_bound,
                                const Zeni::String &ip_address = "",
                                const int &port = 2914 /*sml::Kernel::kDefaultsmlPort*/);

  void step();
  void run(const unsigned long &steps);
  void run_until_halt();

  bool is_finished() const; 
  bool halted() const;

  void reinit(const bool &success);
  void srand(const int &seed);

  /// Set learning parameters

  enum Learning_Policy {SARSA, Q_LEARNING};
  enum Selection_Policy {EPSILON_GREEDY, BOLTZMANN};
  enum Reduction_Policy {LINEAR /** [0,inf) **/, EXPONENTIAL /** [0,1] **/};

  void set_learning(const bool &on = false);
  void set_temporal_extension(const bool &on = true);
  void set_discount_rate(const float &rate = 0.9f); ///< [0,1]
  void set_learning_rate(const float &rate = 0.3f); ///< [0,1]
  void set_learning_policy(const Learning_Policy &policy = SARSA);
  void set_hrl_discount(const bool &on = true);
  void set_eligibility_trace_decay_rate(const float &rate = 0.0f); ///< [0,1]
  void set_eligibility_trace_tolerance(const float &tolerance = 0.001f); ///< (0,inf)
  void set_indifferent_selection(const Selection_Policy &policy);
  void set_epsilon(const float &epsilon = 0.1f); ///< [0,1]
  void set_temperature(const float &temperature = 25.0f); /// < (0,inf)
  void set_epsilon_reduction_rate(const Reduction_Policy &policy, const float &rate);
  void set_temperature_reduction_rate(const Reduction_Policy &policy, const float &rate);
  void set_absolute_bellman_error_limit(const float &limit);
  void set_failed_episode();

  /// Save RL production rules to file 'rl_rules' on exit; empty string to cancel
  void set_save_rl_rules_location(const Zeni::String &rl_rules) {m_rl_rules = rl_rules;}
  void save_rl_rules_now();

  bool connection_closed() {return m_kernel->IsConnectionClosed();}

private:
  void update(sml::Kernel &kernel);
  void state_change(const Zeni::String &name);
  void build_input_link();

  void ecl(const Zeni::String &command);

  VC_State &m_state;
  Soar_Kernel m_kernel;
  Soar_Agent m_agent;
  Input_Link m_input_link;

  std::map<Zeni::String, std::pair<float, std::pair<float, float> > > m_temperatures;
  std::vector<Zeni::String> m_states;
  float m_default_temp;
  float m_default_temp_reduction_rate;

  bool m_finished;

  Zeni::String m_rl_rules;
};

#endif
