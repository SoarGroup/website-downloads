#ifndef REWARD_H
#define REWARD_H

class Reward {
  float m_total;
  float m_current;
  int m_steps;

public:
  Reward();

  float get_total() const {
    return m_total;
  }

  float get_current() const {
    return m_current;
  }

  int num_steps() const {
    return m_steps;
  }

  float reward_per_step() const;

  void reward(const float &value, const bool &step = true);
};

struct Future_Reward {
  Future_Reward();

  bool operator<(const Future_Reward &rhs) const;

  float reward_per_step; ///< e.g. 0.0 if no cycle is present
  float one_shot_reward; ///< terminal reward, or reward achieved in reaching a cycle
};

#endif
