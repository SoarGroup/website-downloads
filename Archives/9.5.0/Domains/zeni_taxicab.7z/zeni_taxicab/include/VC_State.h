#ifndef VC_STATE_H
#define VC_STATE_H

#include "Reward.h"
#include "World.h"

#include <Zeni/Gamestate.h>

namespace sml {}
namespace SML {
  using namespace sml;
}

class VC_Soar;

class VC_State : public Zeni::Gamestate_Base {
  VC_State(const VC_State &);
  VC_State operator=(const VC_State &);

public:
  VC_State(const bool &omniscient,
           const bool &infinite,
           const bool &headless,
           const Zeni::String &rl_rules,
           const Zeni::String &productions,
           const size_t &execution_limit,
           const int &seed,
           const float &temperature,
           const float &temperature_decay_rate,
           const float &temperature_lower_bound,
           const bool &debug,
           const bool &interactive);
  ~VC_State();

  const World & get_world() const {return m_world;}
  const Reward & get_reward() const {return m_reward;}
  Zeni::Random & get_random() {return m_world.random();}

  void move_north();
  void move_south();
  void move_east();
  void move_west();
  void pickup();
  void putdown();
  void fillup();

private:
  void on_event(const SDL_Event &event);
  void on_key(const SDL_KeyboardEvent &event);
  void perform_logic();
  void render();

  void reinit();

  void render_tile(const Point &position, const Zeni::Color &color, const Zeni::String &texture = "");
  void render_letter(const Point &position, const char &letter, const Zeni::Color &color);

  World m_world;
  Reward m_reward;
  VC_Soar * m_vcs;

  size_t m_execution_count;
  size_t m_execution_limit;
  bool m_headless;
  bool m_interactive;

  float max_x;
  float max_y;
  float stride_x;
  float stride_y;
  float half_gap_x;
  float half_gap_y;
};

#endif
