#include <zenilib.h>

#include "Optimal.h"
#include "VC_State.h"
#include "VC_Soar.h"

#include <iomanip>

#define RUN_CUTOFF (10000)
#define VERIFICATION_COUNT (5000u)

using namespace std;
using namespace Zeni;

VC_State::VC_State(const bool &omniscient,
                   const bool &infinite,
                   const bool &headless,
                   const Zeni::String &rl_rules,
                   const Zeni::String &productions,
                   const size_t &execution_limit,
                   const int &seed,
                   const float &temperature,
                   const float &temperature_decay_rate,
                   const float &temperature_lower_bound,
                   const bool &debug,
                   const bool &interactive)
: m_world("maps/default.xml", omniscient, infinite, seed),
#ifdef _WINDOWS
#pragma warning( push )
#pragma warning( disable : 4355 )
#endif
m_vcs(debug
     ? VC_Soar::remote_trial(*this, productions, temperature, temperature_decay_rate, temperature_lower_bound)
     : VC_Soar::local_trial(*this, productions, temperature, temperature_decay_rate, temperature_lower_bound)),
#ifdef _WINDOWS
#pragma warning( pop )
#endif
m_execution_count(0u),
m_execution_limit(execution_limit),
m_headless(headless),
m_interactive(interactive),
max_x(500.0f),
max_y(500.0f),
stride_x(max_x / m_world.width()),
stride_y(max_y / m_world.height()),
half_gap_x(0.05f * stride_x),
half_gap_y(0.05f * stride_y)
{
  m_vcs->set_save_rl_rules_location(rl_rules);
  m_vcs->srand(m_world.random().rand());

  if(!m_headless)
    Window::set_enabled(true);

//   Optimal::Combined_Results cr;
// 
//   cr = Optimal::case_oi();
//   std::cout << cr.num_trials << '\t'
//             << cr.average_steps << '\t'
//             << cr.average_rps_simple << '\t'
//             << cr.average_rps_paper << std::endl;
// 
//   cr = Optimal::case_of();
//   std::cout << cr.num_trials << '\t'
//             << cr.average_steps << '\t'
//             << cr.average_rps_simple << '\t'
//             << cr.average_rps_paper << std::endl;
// 
//   cr = Optimal::case_ui();
//   std::cout << cr.num_trials << '\t'
//             << cr.average_steps << '\t'
//             << cr.average_rps_simple << '\t'
//             << cr.average_rps_paper << std::endl;
// 
//   cr = Optimal::case_uf();
//   std::cout << cr.num_trials << '\t'
//             << cr.average_steps << '\t'
//             << cr.average_rps_simple << '\t'
//             << cr.average_rps_paper << std::endl;
// 
//   throw Quit_Event();
}

VC_State::~VC_State() {
  delete m_vcs;
}

void VC_State::move_north() {
  if(!m_world.terminal())
    m_reward.reward(m_world.move_north());
}

void VC_State::move_south() {
  if(!m_world.terminal())
    m_reward.reward(m_world.move_south());
}

void VC_State::move_east() {
  if(!m_world.terminal())
    m_reward.reward(m_world.move_east());
}

void VC_State::move_west() {
  if(!m_world.terminal())
    m_reward.reward(m_world.move_west());
}

void VC_State::pickup() {
  if(!m_world.terminal())
    m_reward.reward(m_world.pickup());
}

void VC_State::putdown() {
  if(!m_world.terminal())
    m_reward.reward(m_world.putdown());
}

void VC_State::fillup() {
  if(!m_world.terminal())
    m_reward.reward(m_world.fillup());
}

void VC_State::on_event(const SDL_Event &event) {
  try {
    Gamestate_Base::on_event(event);
  }
  catch(...) {
    m_vcs->save_rl_rules_now();
  }
}

void VC_State::on_key(const SDL_KeyboardEvent &event) {
  Gamestate_Base::on_key(event);
}

void VC_State::perform_logic() {
  if(m_interactive) {
    if(m_vcs->connection_closed())
      throw Quit_Event();
    else if((m_world.terminal() && m_vcs->halted())) {
      reinit();
#ifndef NDEBUG
      while(!((m_world.terminal() && m_vcs->halted()) || m_reward.num_steps() > RUN_CUTOFF))
        m_vcs->run(100);
#endif
    }
    else if(m_reward.num_steps() > RUN_CUTOFF)
#ifndef NDEBUG
    {
      static int i = 0u;
      i = RUN_CUTOFF;
      i = m_reward.num_steps();
    }
#else
      reinit();
#endif
  }
  else {
    if(!m_execution_limit) {
      if((m_world.terminal() && m_vcs->halted()) || m_reward.num_steps() > RUN_CUTOFF)
        reinit();
      else
        m_vcs->run(1);
    }
    else if(m_execution_count != m_execution_limit) {
      if((m_world.terminal() && m_vcs->halted()) || m_reward.num_steps() > RUN_CUTOFF) {
        reinit();

        if(m_execution_count + VERIFICATION_COUNT == m_execution_limit)
          m_vcs->set_learning(false);
      }
      else
        m_vcs->run(m_headless ? RUN_CUTOFF + 1 : 1);
    }
    else {
      m_vcs->save_rl_rules_now();
      throw Quit_Event();
    }
  }
}

void VC_State::render() {
  Colors &cr = get_Colors();
  Video &vr = get_Video();
  vr.set_2d_view(make_pair(Point2f(), Point2f(max_x, max_y)),
                 make_pair(Point2i(0, 50), Point2i(500, 550)));

  for(size_t i = 0u; i != m_world.width(); ++i)
    for(size_t j = 0u; j != m_world.height(); ++j)
      render_tile(Point(i, j), cr["white"]);

  for(size_t i = 0u; i != m_world.width(); ++i)
    for(size_t j = 0u; j != m_world.height() - 1; ++j)
      if(!m_world.north_wall(Point(i, j)))
        render_image("",
                     Point2f(stride_x * i            + half_gap_x, max_y - stride_y * j - stride_y - half_gap_y),
                     Point2f(stride_x * i + stride_x - half_gap_x, max_y - stride_y * j - stride_y + half_gap_y),
                     false,
                     cr["white"]);

  for(size_t i = 0u; i != m_world.width() - 1; ++i)
    for(size_t j = 0u; j != m_world.height(); ++j)
      if(!m_world.east_wall(Point(i, j)))
        render_image("",
                     Point2f(stride_x * i + stride_x - half_gap_x, max_y - stride_y * j - stride_y + half_gap_y),
                     Point2f(stride_x * i + stride_x + half_gap_x, max_y - stride_y * j            - half_gap_y),
                     false,
                     cr["white"]);

  render_tile(m_world.fuel(),   cr["purple"]);
  render_tile(m_world.red(),    cr["red"]);
  render_tile(m_world.green(),  cr["green"]);
  render_tile(m_world.blue(),   cr["blue"]);
  render_tile(m_world.yellow(), cr["yellow"]);

  render_letter(m_world.fuel(),   'F', cr["white"]);
  render_letter(m_world.red(),    'R', cr["white"]);
  render_letter(m_world.green(),  'G', cr["black"]);
  render_letter(m_world.blue(),   'B', cr["white"]);
  render_letter(m_world.yellow(), 'Y', cr["black"]);

  if(m_world.passenger() != World::TAXI &&
    (m_world.omniscient() || m_world.type_to_pos(m_world.passenger()) == m_world.taxi()))
    render_tile(m_world.type_to_pos(m_world.passenger()), Color(), "pedestrian");
  render_tile(m_world.taxi(), Color(), "taxi");

  vr.set_2d_view(make_pair(Point2f(), Point2f(500.0f, 50.0f)),
                 make_pair(Point2i(0, 0), Point2i(500, 50)));

  get_Fonts()["description"].render_text(
    "Destination = " + World::type_to_string(m_world.destination()) +
    "\nFuel = " + uitoa(static_cast<unsigned int>(m_world.energy())), Point2f(), Color());

  get_Fonts()["description"].render_text(
    "Reward = " + dtoa(m_reward.get_current(), 3) +
    "\nRPS = " + dtoa(m_reward.reward_per_step(), 3), Point2f(250.0f, 0.0f), Color());
}

void VC_State::reinit() {
  const bool success = m_world.success();

  if(m_world.terminal() || m_reward.num_steps() > RUN_CUTOFF) {
    const size_t start_index = m_world.original_start().first +
      (m_world.height() - 1u - m_world.original_start().second) * m_world.width();
    Optimal::Result optimal;

    if(m_world.omniscient())
      if(m_world.infinite())
        optimal = Optimal::case_oi(start_index, m_world.original_source(), m_world.original_destination(), m_world.original_energy());
      else
        optimal = Optimal::case_of(start_index, m_world.original_source(), m_world.original_destination(), m_world.original_energy());
    else
      if(m_world.infinite())
        optimal = Optimal::case_ui(start_index, m_world.original_source(), m_world.original_destination(), m_world.original_energy());
      else
        optimal = Optimal::case_uf(start_index, m_world.original_source(), m_world.original_destination(), m_world.original_energy());

    cout << (success ? "success" : "failure") << '\t'
         << '\t'
         << setw(5) << m_reward.num_steps() << '\t'
         << setw(5) << m_reward.get_total() << '\t'
         << setw(10) << ((m_reward.get_total() - 1.0f) / m_reward.num_steps()) << '\t'
         << '\t'
         << setw(5) << optimal.steps << '\t'
         << setw(10) << optimal.rps << endl;
  }

  m_world.reinit();
  m_reward = Reward();
  m_vcs->reinit(success);

  ++m_execution_count;
}

void VC_State::render_tile(const Point &position, const Color &color, const Zeni::String &texture) {
  render_image(texture,
               Point2f(stride_x * position.first            + half_gap_x, max_y - stride_y * position.second - stride_y + half_gap_y),
               Point2f(stride_x * position.first + stride_x - half_gap_x, max_y - stride_y * position.second            - half_gap_y),
               false,
               color);
}

void VC_State::render_letter(const Point &position, const char &letter, const Zeni::Color &color) {
  String s;
  s += letter;
  get_Fonts()["world"].render_text(s, Point2f(100.0f * position.first + 50.0f, 400.0f - 100.0f * position.second), color, ZENI_CENTER);
}
