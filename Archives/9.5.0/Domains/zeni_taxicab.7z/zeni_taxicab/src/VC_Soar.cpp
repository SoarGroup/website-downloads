#include <zenilib.h>

#include "VC_Soar.h"

#include <algorithm>
#include <iostream>
#include <sstream>
#include <SDL/SDL.h>

#ifdef _WINDOWS
#include <windows.h>
#endif

//#define ENABLE_FAILURE
#define DISABLE_LEARNING_OVERRIDE
#define DISABLE_LEARNING_CONTROL
#define DO_REMOTE_WITH_LOCAL_KERNEL

using namespace std;
using namespace Zeni;

void vc_update_event_handler(sml::smlUpdateEventId /*id*/, void *user_data_ptr, sml::Kernel* kernel_ptr, sml::smlRunFlags /*run_flags*/) {
  assert(user_data_ptr);
  static_cast<VC_Soar *>(user_data_ptr)->update(*kernel_ptr);
}

VC_Soar::VC_Soar(VC_State &state,
                 const Zeni::String &agent_productions,
                 const float &default_temp,
                 const float &default_temp_reduction_rate,
                 const float &default_temp_lower_bound,
                 const int &port,
                 sml::Kernel * const kernel)
: m_state(state),
  m_kernel(kernel ? kernel :
           sml::Kernel::CreateKernelInNewThread(port)),
#ifdef DO_REMOTE_WITH_LOCAL_KERNEL
  m_agent(m_kernel->CreateAgent("Smith")),
#else
  m_agent(kernel ? m_kernel->GetAgentByIndex(0) : m_kernel->CreateAgent("Smith")),
#endif
  m_input_link(m_agent),
  m_default_temp(default_temp),
  m_default_temp_reduction_rate(default_temp_reduction_rate),
  m_finished(m_state.get_world().terminal())
{
  ecl("watch 0");

  m_agent.LoadProductions(agent_productions.std_str());

  m_kernel->RegisterForUpdateEvent(sml::smlEVENT_AFTER_ALL_OUTPUT_PHASES, vc_update_event_handler, this);

  build_input_link();

  if(!m_agent->Commit())
    abort();

  if(default_temp == 0.0f)
    set_learning(false);
  else {
#ifndef DISABLE_LEARNING_OVERRIDE
    set_learning(true);
    set_learning_rate(0.3f); ///< Arbitrary, but better than 1.0f
    set_learning_policy(SARSA);

    set_temporal_extension(true);
    set_hrl_discount(true);

    set_discount_rate(1.0f);
    set_eligibility_trace_decay_rate(0.0f);
#endif
#ifndef DISABLE_LEARNING_CONTROL
    set_indifferent_selection(BOLTZMANN);
    set_temperature(default_temp);
    set_temperature_reduction_rate(LINEAR, 0.0f);

    m_temperatures["taxi"] = make_pair(default_temp, make_pair(default_temp_reduction_rate, default_temp_lower_bound));

    m_temperatures["maxget"] = make_pair(default_temp, make_pair(default_temp_reduction_rate, default_temp_lower_bound));
    m_temperatures["maxput"] = make_pair(default_temp, make_pair(default_temp_reduction_rate, default_temp_lower_bound));

    m_temperatures["maxrefuel"] = make_pair(default_temp, make_pair(default_temp_reduction_rate, default_temp_lower_bound));

    m_temperatures["maxnavigate"] = make_pair(default_temp, make_pair(default_temp_reduction_rate, default_temp_lower_bound));
#endif
  }
}

VC_Soar * VC_Soar::local_trial(VC_State &state,
                               const Zeni::String &agent_productions,
                               const float &default_temp,
                               const float &default_temp_reduction_rate,
                               const float &default_temp_lower_bound,
                               const int &port)
{
  return new VC_Soar(state,
                     agent_productions,
                     default_temp,
                     default_temp_reduction_rate,
                     default_temp_lower_bound,
                     port);
}

#ifdef _WINDOWS
static int launch(const Zeni::String &command) {
  char dir[32768];
  const DWORD nSize = GetModuleFileNameA(NULL, dir, sizeof(dir) - 1);
  if(!nSize || GetLastError() == ERROR_INSUFFICIENT_BUFFER)
    return -1;
  else
    dir[nSize] = '\0';

  for(int i = int(nSize) - 1; i != -1; --i)
    if(dir[i] == '\\') {
      dir[i] = '\0';
      break;
    }
    else
      dir[i] = '\0';

  STARTUPINFOA siStartupInfo;
  PROCESS_INFORMATION piProcessInfo;
  memset(&siStartupInfo, 0, sizeof(siStartupInfo));
  memset(&piProcessInfo, 0, sizeof(piProcessInfo));
  siStartupInfo.cb = sizeof(siStartupInfo);

#ifdef NDEBUG
  siStartupInfo.dwFlags |= STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
  siStartupInfo.wShowWindow = SW_HIDE;
#endif

  bool result = CreateProcessA(NULL,
                               LPSTR(command.c_str()),
                               NULL,
                               NULL,
                               FALSE,
                               0,
                               NULL,
                               NULL,
                               &siStartupInfo,
                               &piProcessInfo) != 0;

  if(!result)
    return 2;

  return 0;
}
#endif

VC_Soar * VC_Soar::remote_trial(VC_State &state,
                                const Zeni::String &agent_productions,
                                const float &default_temp,
                                const float &default_temp_reduction_rate,
                                const float &default_temp_lower_bound,
                                const Zeni::String &ip_address,
                                const int &port)
{
#ifdef DO_REMOTE_WITH_LOCAL_KERNEL

  VC_Soar *vcs =  new VC_Soar(state,
                              agent_productions,
                              default_temp,
                              default_temp_reduction_rate,
                              default_temp_lower_bound,
                              port);

#ifdef _WINDOWS
#ifdef NDEBUG
  if(launch("cmd /c cd \"C:\\Users\\bazald\\Documents\\My Work\\svn\\cppsoar\\bin\" && \"C:\\Program Files\\Java\\jdk1.6.0_17\\bin\\java.exe\" -jar SoarJavaDebugger.jar -port " + Zeni::itoa(port) + " && exit"))
#else
  if(launch("cmd /k cd \"C:\\Users\\bazald\\Documents\\My Work\\svn\\cppsoar\\bin\" && \"C:\\Program Files\\Java\\jdk1.6.0_17\\bin\\java.exe\" -jar SoarJavaDebugger.jar -port " + Zeni::itoa(port) + " && exit"))
#endif
    throw Zeni::Error("Launching SoarJavaDebugger failed.");
#else
  if(!fork()) {
    std::ostringstream output, error;
    std::cout.rdbuf(output.rdbuf());
    ;//std::cerr.rdbuf(output.rdbuf());
    exit(system(("/usr/bin/java -jar /home/bazald/Documents/Work/soar-group/cppsoar/bin/SoarJavaDebugger.jar -port " + Zeni::itoa(port)).c_str()));
  }
#endif

#else

#ifdef _WINDOWS
#ifdef NDEBUG
  if(launch("cmd /c cd \"C:\\Users\\bazald\\Documents\\My Work\\svn\\cppsoar\\bin\" && \"C:\\Program Files\\Java\\jdk1.6.0_17\\bin\\java.exe\" -jar SoarJavaDebugger.jar -listen " + Zeni::itoa(port) + " && exit"))
#else
  if(launch("cmd /k cd \"C:\\Users\\bazald\\Documents\\My Work\\svn\\cppsoar\\bin\" && \"C:\\Program Files\\Java\\jdk1.6.0_17\\bin\\java.exe\" -jar SoarJavaDebugger.jar -listen " + Zeni::itoa(port) + " && exit"))
#endif
    throw Zeni::Error("Launching SoarJavaDebugger failed.");
#else
  if(!fork()) {
    std::ostringstream output, error;
    std::cout.rdbuf(output.rdbuf());
    ;//std::cerr.rdbuf(output.rdbuf());
    exit(system(("/usr/bin/java -jar /home/bazald/Documents/Work/soar-group/cppsoar/bin/SoarJavaDebugger.jar -listen " + Zeni::itoa(port)).c_str()));
  }
#endif

  sml::Kernel *sml_kernel_ptr = 0;

#ifndef _WINDOWS
  /// Temporarily redirect C-style output
  FILE *temp = fopen("/dev/null", "w");
  FILE *out = stdout;
  FILE *err = stderr;
  stdout = temp;
  stderr = temp;
#endif

  try {
    for(int i = 0; i != 100; ++i) {
      SDL_Delay(100);
      sml_kernel_ptr = sml::Kernel::CreateRemoteConnection(true,
                                                          ip_address.empty() ? 0 : ip_address.c_str(),
                                                          port,
                                                          false);
      if(sml_kernel_ptr->HadError())
        delete sml_kernel_ptr;
      else
        goto SUCCESS;
    }

    throw Zeni::Error("Kernel remote connection failed.");
  }
  catch(...) {
    /// End redirection of C-style output
#ifndef _WINDOWS
    stdout = out;
    stderr = err;
#endif
    throw;
  }

SUCCESS:

#ifndef _WINDOWS
  /// End redirection of C-style output
  stdout = out;
  stderr = err;
#endif

  VC_Soar *vcs = new VC_Soar(state,
                             agent_productions,
                             default_temp,
                             default_temp_reduction_rate,
                             default_temp_lower_bound,
                             port,
                             sml_kernel_ptr);

#endif

  return vcs;
}

void VC_Soar::step() {
  if(is_finished())
    return;

  m_agent->RunSelf(1u);
}

void VC_Soar::run(const unsigned long &steps) {
  m_agent->RunSelf(steps);
}

void VC_Soar::run_until_halt() {
  m_agent->RunSelfForever();
}

bool VC_Soar::is_finished() const {
  return m_finished;
}

bool VC_Soar::halted() const {
  return const_cast<Soar_Agent &>(m_agent)->GetRunState() == sml::sml_RUNSTATE_HALTED;
}

void VC_Soar::reinit(const bool &success) {
  m_input_link.clear();

// #ifndef NDEBUG
//   cerr << "Closing log." << endl;
//   ecl("clog -c");
//   cerr << "Log closed." << endl;
// #endif

//   ;//std::cerr << "Reinit" << std::endl;

#ifndef DISABLE_LEARNING_CONTROL
  if(success) {
    for(std::vector<Zeni::String>::const_iterator it = m_states.begin(); it != m_states.end(); ++it) {
      std::map<Zeni::String, std::pair<float, std::pair<float, float> > >::iterator jt = m_temperatures.find(*it);
      if(jt == m_temperatures.end())
        continue;
      std::pair<float, std::pair<float, float> > &temp = jt->second;
      const float temp_next = temp.first * temp.second.first;

      if(temp_next > temp.second.second) {
        temp.first = temp_next;
#ifndef NDEBUG
        ;//std::cerr << *it << " temperature reduced to " << temp.first << std::endl;
#endif
      }
    }
  }
#endif

  m_states.clear();

  // Must Commit before InitSoar
  if(!m_agent->Commit())
    abort();

  m_agent->InitSoar();

#ifndef DISABLE_LEARNING_CONTROL
  set_temperature(m_temperatures["taxi"].first);
#endif

// #ifndef NDEBUG
//   ++m_init_count;
//   if(m_init_count > 58985 /* 3 less to be "sure" */ ||
//      m_init_count < 10 /* Quick test */)
//   {
//     cerr << "Opening log." << endl;
//     ecl("clog partial_12502_" + Zeni::itoa(m_init_count) + ".log");
//     ecl("watch 5");
//     cerr << "Log open." << endl;
//   }
// #endif

  build_input_link();
}

void VC_Soar::srand(const int &seed) {
  ecl("srand " + Zeni::itoa(seed));
}

void VC_Soar::set_learning(const bool &on) {
  ecl("rl --set learning " + String(on ? "on" : "off"));

  if(!on) {
    set_learning_rate(0.0f);
    set_indifferent_selection(EPSILON_GREEDY);
    set_epsilon(0.0f);
  }
}

void VC_Soar::set_temporal_extension(const bool &on) {
  ecl("rl --set temporal-extension " + String(on ? "on" : "off"));
}

void VC_Soar::set_discount_rate(const float &rate) {
  ecl("rl --set discount-rate " + Zeni::ftoa(rate));
}

void VC_Soar::set_learning_rate(const float &rate) {
  ecl("rl --set learning-rate " + Zeni::ftoa(rate));
}

void VC_Soar::set_learning_policy(const Learning_Policy &policy) {
  ecl("rl --set learning-policy " + String(policy == SARSA ? "sarsa" : "q-learning"));
}

void VC_Soar::set_hrl_discount(const bool &on) {
  ecl("rl --set hrl-discount " + String(on ? "on" : "off"));
}

void VC_Soar::set_eligibility_trace_decay_rate(const float &rate) {
  ecl("rl --set eligibility-trace-decay-rate " + Zeni::ftoa(rate));
}

void VC_Soar::set_eligibility_trace_tolerance(const float &tolerance) {
  ecl("rl --set eligibility-trace-tolerance " + Zeni::ftoa(tolerance));
}

void VC_Soar::set_indifferent_selection(const Selection_Policy &policy) {
  ecl("indifferent-selection --" + String(policy == EPSILON_GREEDY ? "epsilon-greedy" : "boltzmann"));
}

void VC_Soar::set_epsilon(const float &epsilon) {
  ecl("indifferent-selection --epsilon " + Zeni::ftoa(epsilon));
}

void VC_Soar::set_temperature(const float &temperature) {
  ecl("indifferent-selection --temperature " + Zeni::ftoa(temperature));
}

void VC_Soar::set_epsilon_reduction_rate(const Reduction_Policy &policy, const float &rate) {
  ecl("indifferent-selection --reduction-rate epsilon " + String(policy == LINEAR ? "linear" : "exponential") + " " + Zeni::ftoa(rate));
}

void VC_Soar::set_temperature_reduction_rate(const Reduction_Policy &policy, const float &rate) {
  ecl("indifferent-selection --reduction-rate temperature " + String(policy == LINEAR ? "linear" : "exponential") + " " + Zeni::ftoa(rate));
}

void VC_Soar::set_absolute_bellman_error_limit(const float &limit) {
  ecl("rl --set absolute-bellman-error-limit " + Zeni::ftoa(limit));
}

void VC_Soar::set_failed_episode() {
#ifdef ENABLE_FAILURE
  ecl("rl --set failed-episode on");
#endif
}

void VC_Soar::save_rl_rules_now() {
  if(!m_rl_rules.empty()) {
    const Zeni::String cmd = "command-to-file " + m_rl_rules + " print --rl --full";
    ;//std::cerr << cmd << std::endl;
    ecl(cmd);
  }
}

void VC_Soar::update(sml::Kernel &/*kernel*/) {
  // Go through all the commands we've received (if any) since we last ran Soar.
  const int num_commands = m_agent->GetNumberCommands();

  for(int i = 0; i != num_commands; ++i) {
    sml::Identifier * const command_ptr = m_agent->GetCommand(i);

    if(!(strcmp("state", command_ptr->GetCommandName()))) {
      const char * name = command_ptr->GetParameterValue("name");
       state_change(name);
    }
    else if(!strcmp("move", command_ptr->GetCommandName())) {
      const char * direction = command_ptr->GetParameterValue("direction");

      if(direction) {
        if(!strcmp("north", direction)) {
#ifndef NDEBUG
          ;//std::cerr << "Operator: Move North" << std::endl;
#endif
          m_state.move_north();
        }
        else if(!strcmp("south", direction)) {
#ifndef NDEBUG
          ;//std::cerr << "Operator: Move South" << std::endl;
#endif
          m_state.move_south();
        }
        else if(!strcmp("east", direction)) {
#ifndef NDEBUG
          ;//std::cerr << "Operator: Move East" << std::endl;
#endif
          m_state.move_east();
        }
        else if(!strcmp("west", direction)) {
#ifndef NDEBUG
          ;//std::cerr << "Operator: Move West" << std::endl;
#endif
          m_state.move_west();
        }
        else
          command_ptr->AddStatusError();
      }
      else
        command_ptr->AddStatusError();
    }
    else if(!strcmp("pickup", command_ptr->GetCommandName())) {
#ifndef NDEBUG
      ;//std::cerr << "Operator: Pickup" << std::endl;
#endif
      m_state.pickup();
    }
    else if(!strcmp("putdown", command_ptr->GetCommandName())) {
#ifndef NDEBUG
      ;//std::cerr << "Operator: Putdown" << std::endl;
#endif
      m_state.putdown();
    }
    else if(!strcmp("fillup", command_ptr->GetCommandName())) {
#ifndef NDEBUG
      ;//std::cerr << "Operator: Fillup" << std::endl;
#endif
      m_state.fillup();
    }
    else
      command_ptr->AddStatusError();

    // Update environment here to reflect agent's command
    // Then mark the command as completed
    command_ptr->AddStatusComplete();
  }
//   else if(num_commands) {
//     for(int i = 0; i < num_commands; ++i) {
//       sml::Identifier * const command_ptr = m_agent->GetCommand(i);
//       command_ptr->AddStatusError();
//     }
//   }

#ifndef NDEBUG
  ;//std::cerr << "Fuel Remaining: " << m_state.get_world().energy() << std::endl;
#endif

  build_input_link();

  m_agent->ClearOutputLinkChanges();
}

void VC_Soar::state_change(const Zeni::String &name) {
#ifndef DISABLE_LEARNING_CONTROL
  std::vector<Zeni::String>::iterator it = std::find(m_states.begin(), m_states.end(), name);

  if(it != m_states.end()) {
    for(size_t j = m_states.size() - 1u, j_end = it - m_states.begin(); j != j_end; --j) {
//       ;//std::cerr << "Leaving State: " << *m_states.rbegin() << std::endl;

      std::map<Zeni::String, std::pair<float, std::pair<float, float> > >::iterator jt = m_temperatures.find(*m_states.rbegin());
      if(jt == m_temperatures.end())
        continue;
      std::pair<float, std::pair<float, float> > &temp = jt->second;
      const float temp_next = temp.first * temp.second.first;

      if(temp_next > temp.second.second) {
        temp.first = temp_next;
#ifndef NDEBUG
        ;//std::cerr << *m_states.rbegin() << " temperature reduced to " << temp.first << std::endl;
#endif
      }

      m_states.pop_back();
    }
  }
  else {
    m_states.push_back(name);
//     ;//std::cerr << "Entering State: " << name << std::endl;
  }

  std::map<Zeni::String, std::pair<float, std::pair<float, float> > >::iterator jt = m_temperatures.find(*m_states.rbegin());
  if(jt == m_temperatures.end())
#ifndef NDEBUG
    ;//std::cerr << "Ignored state: " << *m_states.rbegin() << std::endl;
#else
    ;
#endif
  else
    set_temperature(jt->second.first);
#endif
}

void VC_Soar::build_input_link() {
  const World &w = m_state.get_world();

  {Input_Link::WME_Node &s = m_input_link["self"];
    {Input_Link::WME_Node &s_pos = s["position"];
      s_pos["x"] = w.taxi().first;
      s_pos["y"] = w.taxi().second;
    }
    s["reward"] = int(m_state.get_reward().get_current());
//     s["random"] = m_state.get_random().frand_lt(); // Ruins determinism across multiple agents - must use different Random object
    s["passenger"] = bool(w.passenger() == World::TAXI);
    if(w.destination() != World::TAXI)
      s["destination"] = World::type_to_string(w.destination());
    else
      s.erase("destination");
    s["fuel"] = w.energy();
  }
  {Input_Link::WME_Node &v = m_input_link["view"];
    {Input_Link::WME_Node &vn = v["north"];
      const Point next(w.taxi().first, w.taxi().second + 1u);
      vn["type"] = World::type_to_string(w.pos_to_type(next));
      vn["wall"] = w.north_wall(w.taxi());
      vn["passenger"] = bool(w.passenger() != World::TAXI && w.type_to_pos(w.passenger()) == next);
    }
    {Input_Link::WME_Node &vs = v["south"];
      const Point next(w.taxi().first, w.taxi().second - 1u);
      vs["type"] = World::type_to_string(w.pos_to_type(next));
      vs["wall"] = w.north_wall(next);
      vs["passenger"] = bool(w.passenger() != World::TAXI && w.type_to_pos(w.passenger()) == next);
    }
    {Input_Link::WME_Node &ve = v["east"];
      const Point next(w.taxi().first + 1u, w.taxi().second);
      ve["type"] = World::type_to_string(w.pos_to_type(next));
      ve["wall"] = w.east_wall(w.taxi());
      ve["passenger"] = bool(w.passenger() != World::TAXI && w.type_to_pos(w.passenger()) == next);
    }
    {Input_Link::WME_Node &vw = v["west"];
      const Point next(w.taxi().first - 1u, w.taxi().second);
      vw["type"] = World::type_to_string(w.pos_to_type(next));
      vw["wall"] = w.east_wall(next);
      vw["passenger"] = bool(w.passenger() != World::TAXI && w.type_to_pos(w.passenger()) == next);
    }
  }
  {Input_Link::WME_Node &c = m_input_link["cell"];
    c["type"] = World::type_to_string(w.pos_to_type(w.taxi()));
    c["passenger"] = bool(w.passenger() != World::TAXI && w.type_to_pos(w.passenger()) == w.taxi());
  }
  {Input_Link::WME_Node &c = m_input_link["cheat"];
    {Input_Link::WME_Node &o = c["oracle"];
      o["source"] = World::type_to_string(w.source());
      o["destination"] = World::type_to_string(w.destination());
    }
  }

  if(!m_agent->Commit())
    abort();

  m_finished = m_state.get_world().terminal();
  
  if(m_finished && m_state.get_world().failure())
    set_failed_episode();
}

void VC_Soar::ecl(const Zeni::String &command) {
  const char * const output = m_agent->ExecuteCommandLine(command.c_str());

  if(output)
    ;//std::cerr << command << std::endl << output << std::endl;
  else
    abort();
}
