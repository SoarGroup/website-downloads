/* This file is part of the Zenipex Library (zenilib).
 * Copyleft (C) 2011 Mitchell Keith Bloch (bazald).
 *
 * This source file is simply under the public domain.
 */

#include <zenilib.h>

#include <iostream>
#include <fstream>
#include <ctime>

#include "VC_State.h"

#if defined(_DEBUG) && defined(_WINDOWS)
#define DEBUG_NEW new(_NORMAL_BLOCK, __FILE__, __LINE__)
#define new DEBUG_NEW
#endif

using namespace std;
using namespace Zeni;

static std::vector<String> g_args;

static void usage() {
  cout << "Usage:     executable [arguments] productions.soar execution_limit" << endl;
  cout << "                                                   0 meaning inf" << endl;
  cout << "Arguments:" << endl;
  cout << "  --informed to allow the agent to know the source & destination from the beginning" << endl;
  cout << "  --uninformed to force the agent to learn the destination only after finding and picking up the passenger" << endl;
  cout << "  --infinite to give the taxi permanently maxed out fuel [12]" << endl;
  cout << "  --finite to given the taxi [5,12] fuel, refueling yielding [12]" << endl;
  cout << "  --headless to run without user interaction" << endl;
  cout << "  --seed [-inf,inf] to set a random seed" << endl;
  cout << "  --learn <initial-temperature> <exponential-decay-rate> <lower-bound>" << endl;
  cout << "  --save_rl <file> save learned RL productions to a file" << endl;
  cout << "  --debug to connect to the SoarJavaDebugger (already running)" << endl;
  cout << "  --interactive to disable automatic stepping; implies --debug" << endl;
  throw Quit_Event();
}

class Instructions_State : public Widget_Gamestate {
  Instructions_State(const Instructions_State &);
  Instructions_State operator=(const Instructions_State &);

public:
  Instructions_State()
    : Widget_Gamestate(make_pair(Point2f(0.0f, 0.0f), Point2f(800.0f, 600.0f)))
  {
  }

private:
  void on_key(const SDL_KeyboardEvent &event) {
    if(event.keysym.sym == SDLK_ESCAPE && event.state == SDL_PRESSED)
      get_Game().pop_state();
  }

  void render() {
    Widget_Gamestate::render();

    Zeni::Font &fr = get_Fonts()["title"];

    fr.render_text(
#if defined(_WINDOWS)
                   "ALT+F4"
#elif defined(_MACOSX)
                   "Apple+Q"
#else
                   "Ctrl+Q"
#endif
                           " to Quit",
                   Point2f(400.0f, 300.0f - 0.5f * fr.get_text_height()),
                   get_Colors()["title_text"],
                   ZENI_CENTER);
  }
};

class Bootstrap {
  class Gamestate_One_Initializer : public Gamestate_Zero_Initializer {
    virtual Gamestate_Base * operator()() {
      Window::set_title("zenilib Application");

//       get_Joysticks();
//       get_Video();
//       get_Textures();
//       get_Fonts();
//       get_Sounds();
//       get_Game().joy_mouse.enabled = true;

      if(g_args.size() < 2u)
        usage();

      bool omniscient = true;
      bool infinite = false;
      bool headless = false;
      bool debug = false;
      bool interactive = false;
      String rl_rules;
      String output_file;
      int seed = int(time(0));

      float temperature = 0.0f;
      float temperature_decay_rate = 0.0f;
      float temperature_lower_bound = 0.0f;

      const size_t execution_limit = atoi((*g_args.rbegin()).c_str());
      g_args.pop_back();

      const String productions = *g_args.rbegin();
      g_args.pop_back();

      if(!g_args.empty())
        for(vector<String>::const_iterator it = g_args.begin(); it != g_args.end(); ++it) {
          if(*it == "--help")
            usage();
          else if(*it == "--informed")
            omniscient = true;
          else if(*it == "--uninformed")
            omniscient = false;
          else if(*it == "--infinite")
            infinite = true;
          else if(*it == "--finite")
            infinite = false;
          else if(*it == "--headless")
            headless = true;
          else if(*it == "--seed") {
            if(++it != g_args.end())
              seed = atoi((*it).c_str());
            else
              throw Error("Missing Value For Argument: '--seed'");
          }
          else if(*it == "--learn") {
            if(++it != g_args.end()) {
              temperature = float(atof((*it).c_str()));
              if(++it != g_args.end()) {
                temperature_decay_rate = float(atof((*it).c_str()));
                if(++it != g_args.end()) {
                  temperature_lower_bound = float(atof((*it).c_str()));
                }
                else
                  throw Error("Missing 3rd Value For Argument: '--learn'");
              }
              else
                throw Error("Missing 2nd Value For Argument: '--learn'");
            }
            else
              throw Error("Missing 1st Value For Argument: '--learn'");
          }
          else if(*it == "--save_rl") {
            if(++it != g_args.end())
              rl_rules = *it;
            else
              throw Error("Missing Value For Argument: '--save_rl'");
          }
          else if(*it == "--output") {
            if(++it != g_args.end())
              output_file = *it;
            else
              throw Error("Missing Value For Argument: '--output'");
          }
          else if(*it == "--debug") {
            debug = true;
          }
          else if(*it == "--interactive") {
            debug = true;
            interactive = true;
          }
          else
            throw Error("Invalid Argument: " + *it);
        }

      if(!output_file.empty()) {
        static std::ofstream cout_file("stdout.txt");
        std::cout.rdbuf(cout_file.rdbuf());
      }

      cout << "Random Seed = " << seed << endl;

      return new VC_State(omniscient,
                          infinite,
                          headless,
                          rl_rules,
                          productions,
                          execution_limit,
                          seed,
                          temperature,
                          temperature_decay_rate,
                          temperature_lower_bound,
                          debug,
                          interactive);
    }
  } m_goi;

public:
  Bootstrap() {
    g_gzi = &m_goi;
  }
} g_bootstrap;

int main(int argc, char **argv) {
  for(int i = 1; i < argc; ++i)
    g_args.push_back(argv[i]);

  return zenilib_main(argc, argv);
}
