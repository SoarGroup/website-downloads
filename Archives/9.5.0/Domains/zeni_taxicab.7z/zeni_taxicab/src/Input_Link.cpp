#include <zenilib.h>

#include "Input_Link.h"

Input_Link::WME_Node::WME_Node(Soar_Agent &agent, sml::Identifier &parent, const Zeni::String &index)
: m_agent(agent),
m_parent(parent),
m_index(index),
m_type(NONE),
m_value(0)
{
  m_ptr.ident = 0;
}

Input_Link::WME_Node::~WME_Node() {
  destroy_pv();
}

Input_Link::WME_Node & Input_Link::WME_Node::operator[](const Zeni::String &index) {
  std::map<Zeni::String, WME_Node *>::iterator it = m_nodes.find(index);
  if(it != m_nodes.end())
    return *it->second;
  else {
    if(m_type != ID) {
      destroy_pv();
      m_type = ID;
      m_ptr.ident = m_agent->CreateIdWME(&m_parent, m_index.c_str());
    }

    return *(m_nodes[index] = new WME_Node(m_agent, *m_ptr.ident, index));
  }
}

void Input_Link::WME_Node::operator=(const Zeni::String &s) {
  if(m_type != STRING || *static_cast<Zeni::String *>(m_value) != s) {
    destroy_pv();
    m_type = STRING;
    m_ptr.s = m_agent->CreateStringWME(&m_parent, m_index.c_str(), s.c_str());
    m_value = new Zeni::String(s);
  }
}

void Input_Link::WME_Node::operator=(const int &i) {
  if(m_type != INT || *static_cast<int *>(m_value) != i) {
    destroy_pv();
    m_type = INT;
    m_ptr.i = m_agent->CreateIntWME(&m_parent, m_index.c_str(), i);
    m_value = new int(i);
  }
}

void Input_Link::WME_Node::operator=(const float &f) {
  if(m_type != FLOAT || *static_cast<float *>(m_value) != f) {
    destroy_pv();
    m_type = FLOAT;
    m_ptr.f = m_agent->CreateFloatWME(&m_parent, m_index.c_str(), f);
    m_value = new float(f);
  }
}

void Input_Link::WME_Node::erase(const Zeni::String &s) {
  std::map<Zeni::String, WME_Node *>::iterator it = m_nodes.find(s);
  if(it != m_nodes.end()) {
    delete it->second;
    m_nodes.erase(it);
  }
}

void Input_Link::WME_Node::destroy_pv() {
  /** Destroy all children **/

  for(std::map<Zeni::String, WME_Node *>::iterator it = m_nodes.begin(); it != m_nodes.end(); ++it)
    delete it->second;

  m_nodes.clear();

  /** Destroy this WME **/

  if(m_ptr.ident)
    if(!m_agent->GetKernel()->IsConnectionClosed()) // Hangs/Segfaults if already closed
      m_agent->DestroyWME(m_ptr.ident);

  switch(m_type) {
    case STRING:
      delete static_cast<Zeni::String *>(m_value);
      break;

    case INT:
      delete static_cast<int *>(m_value);
      break;

    case FLOAT:
      delete static_cast<float *>(m_value);
      break;

    default:
      break;
  }

  m_type = NONE;
  m_ptr.ident = 0;
  m_value = 0;
}

Input_Link::Input_Link(Soar_Agent &agent)
: m_agent(agent)
{
}

Input_Link::~Input_Link() {
  for(std::map<Zeni::String, WME_Node *>::iterator it = m_nodes.begin(); it != m_nodes.end(); ++it)
    delete it->second;
}

Input_Link::WME_Node & Input_Link::operator[](const Zeni::String &index) {
  std::map<Zeni::String, WME_Node *>::iterator it = m_nodes.find(index);
  if(it != m_nodes.end())
    return *it->second;
  else
    return *(m_nodes[index] = new WME_Node(m_agent, *m_agent->GetInputLink(), index));
}

void Input_Link::erase(const Zeni::String &s) {
  std::map<Zeni::String, WME_Node *>::iterator it = m_nodes.find(s);
  if(it != m_nodes.end()) {
    delete it->second;
    m_nodes.erase(it);
  }
}

void Input_Link::clear() {
  for(std::map<Zeni::String, WME_Node *>::iterator it = m_nodes.begin(); it != m_nodes.end(); ++it)
    delete it->second;
  m_nodes.clear();
}
