#!/bin/bash

rm ~/.Zeni_Taxicab/config/zenilib.xml &> /dev/null
cp config/zenilib.orig config/zenilib.xml

SEED=$RANDOM
echo seed=$SEED

./application --informed --finite --headless --seed $SEED --learn 50 0.99997 0.5 agents/taxi-rl-oracle.soar 52000
