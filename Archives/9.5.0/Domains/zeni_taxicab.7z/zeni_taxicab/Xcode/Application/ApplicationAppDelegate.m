//
//  ApplicationAppDelegate.m
//  Application
//
//  Created by Mitchell Keith Bloch on 8/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ApplicationAppDelegate.h"

@implementation ApplicationAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
