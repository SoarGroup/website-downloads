This c++ agent is meant to select random actions for all the generalized domains in the rl-competition. This agent does not learn.

The random agent works with the all of the domains.

To recompile just the random c++ agent:
>> make clean
>> make

in randomAgentCPP directory.

>>bash run.bash:
- Starts the randomAgentCPP process

You need to start a trainer separately.
