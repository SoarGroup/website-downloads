const char* kTimestamp = __TIME__;
const char* kDatestamp = __DATE__;
//* Last build of Soar 9.6.0 occurred at Fri Mar 24 15:25:56 2017 *//
