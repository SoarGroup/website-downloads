package org.msoar.gridmap2d.config;


public class KitchenConfig implements GameConfig {
	public String title() {
		return "Kitchen";
	}
}
