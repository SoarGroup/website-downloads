//
//  iSoarTests.h
//  iSoarTests
//
//  Created by Nate on 5/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface iSoarTests : SenTestCase {
@private
    
}

@end
