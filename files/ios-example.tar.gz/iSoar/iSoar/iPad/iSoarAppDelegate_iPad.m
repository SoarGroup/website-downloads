//
//  iSoarAppDelegate_iPad.m
//  iSoar
//
//  Created by Nate on 5/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "iSoarAppDelegate_iPad.h"

@implementation iSoarAppDelegate_iPad

- (void)dealloc
{
	[super dealloc];
}

@end
