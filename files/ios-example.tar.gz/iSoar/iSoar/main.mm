//
//  main.m
//  iSoar
//
//  Created by Nate on 5/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#include "portability.h"
#include "sml_Connection.h"
#include "sml_Client.h"
#include "ElementXML.h"

int main(int argc, char *argv[])
{
	sml::Kernel* pKernel = sml::Kernel::CreateKernelInNewThread(sml::Kernel::kDefaultLibraryName, 0);
	sml::Agent* pAgent = pKernel->CreateAgent( "iSoar" ) ;
	std::cout << pAgent->ExecuteCommandLine("stats");
	delete pKernel;
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, nil);
	[pool release];
	return retVal;
}
