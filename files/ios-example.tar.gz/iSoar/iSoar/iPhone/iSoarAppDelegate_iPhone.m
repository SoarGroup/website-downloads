//
//  iSoarAppDelegate_iPhone.m
//  iSoar
//
//  Created by Nate on 5/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "iSoarAppDelegate_iPhone.h"

@implementation iSoarAppDelegate_iPhone

- (void)dealloc
{
	[super dealloc];
}

@end
