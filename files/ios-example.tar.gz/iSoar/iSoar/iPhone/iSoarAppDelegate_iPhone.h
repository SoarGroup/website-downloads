//
//  iSoarAppDelegate_iPhone.h
//  iSoar
//
//  Created by Nate on 5/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iSoarAppDelegate.h"

@interface iSoarAppDelegate_iPhone : iSoarAppDelegate {
    
}

@end
