package edu.umich.soar.visualsoar.misc;

public class TemplateInstantiationException extends Exception {
    private static final long serialVersionUID = 20221225L;

    public TemplateInstantiationException(String s) {
        super(s);
    }
}
