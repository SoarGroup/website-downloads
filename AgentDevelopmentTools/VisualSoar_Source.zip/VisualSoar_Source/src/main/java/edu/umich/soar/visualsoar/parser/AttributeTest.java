package edu.umich.soar.visualsoar.parser;

public final class AttributeTest {
    // Data Members
    private final Test d_test;

    // Constructor
    public AttributeTest(Test test) {
        d_test = test;
    }

    // Accessors
    public Test getTest() {
        return d_test;
    }
}
